package com.jieli.app.payassistant.ui;

import android.view.View;

/**
 * Des:
 * Author: Bob
 * Date:20-7-30
 * UpdateRemark:
 */
public interface OnItemClickListener<T> {
    void onItemClick(View view, T t, int position);

    void onItemLongClick(View view, T t, int position);
}
