package com.jieli.app.payassistant.home;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.PermissionChecker;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.jieli.app.payassistant.R;
import com.jieli.app.payassistant.bean.SettingInfo;
import com.jieli.app.payassistant.home.presenter.HomePresenter;
import com.jieli.app.payassistant.main.MainActivity;
import com.jieli.app.payassistant.netconfig.BleConfigFragment;
import com.jieli.app.payassistant.ui.BaseFragment;
import com.jieli.app.payassistant.ui.adapter.SettingItemAdapter;
import com.jieli.app.payassistant.util.CommonUtil;
import com.jieli.app.payassistant.util.Const;
import com.jieli.app.payassistant.util.Jlog;
import com.jieli.app.payassistant.util.ToastUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 2020/8/27 2:51 PM
 * @desc : 蓝牙配网
 */
public class HomeFragment extends BaseFragment {

    private HomePresenter mPresenter;

    public static HomeFragment newInstance() {
        HomeFragment fragment = new HomeFragment();
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Jlog.d(tag, "onCreate");
        if (mPresenter == null) {
            mPresenter = new HomePresenter(this);
            getActivity().getLifecycle().addObserver(mPresenter);
        }

    }



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        RecyclerView recyclerView = root.findViewById(R.id.rv_setting);
        SettingItemAdapter adapter = new SettingItemAdapter();
        String[] settings = getResources().getStringArray(R.array.setting_info_text_list);
        String[] settingsTip = getResources().getStringArray(R.array.setting_info_tip_text_list);
        List<SettingInfo> list = new ArrayList<>();
        for (int i = 0; i < settings.length; i++) {
            list.add(new SettingInfo(i, settings[i],settingsTip[i]));
        }
        adapter.setNewInstance(list);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        recyclerView.addItemDecoration(new DividerItemDecoration(requireContext(), RecyclerView.VERTICAL));

        adapter.setOnItemClickListener((adapter1, view, position) -> {
            String funText = adapter.getData().get(position).getText();
            if (funText.equals(getString(R.string.fast_config_network))) {
                ((MainActivity) requireActivity()).switchFragment(BleConfigFragment.class);
            } else if (funText.equals(getString(R.string.notify_use_permission))) {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
                intent.addCategory(Intent.CATEGORY_DEFAULT);
                startActivity(intent);
            } else if (funText.equals(getString(R.string.app_mananger))) {
                mPresenter.openAppSetting(requireActivity().getPackageName());
            } else if (funText.equals(getString(R.string.wx_setting))) {
                mPresenter.openAppSetting("com.tencent.mm");
            } else if (funText.equals(getString(R.string.alipay_setting))) {
                mPresenter.openAppSetting("com.eg.android.AlipayGphone");
            } else if (funText.equals(getString(R.string.app_launcher_mananger))) {
                CommonUtil.openStart(requireContext());
            } else if (funText.equals(getString(R.string.payment_wechat))) {
                mPresenter.createNotification(Const.PAY_TITLE_WECHAT);
            } else if (funText.equals(getString(R.string.payment_ali))) {
                mPresenter.createNotification(Const.PAY_TITLE_ALI);
            }
        });

        root.findViewById(R.id.btn_unbind).setOnClickListener(v -> mPresenter.unbindDevice());

        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Jlog.d(tag, "onActivityCreated");
        mPresenter.requestBondDevice();
    }




    public void onRequestBond(String clientId) {
        if(getView()==null){
            return;
        }
        TextView textView = requireView().findViewById(R.id.tv_bind);
        if (TextUtils.isEmpty(clientId)) {
            clientId = getString(R.string.msg_not_bond_device);
        }
        textView.setText(getString(R.string.bonded, clientId));
    }

    public void onShowMsg(String msg) {
        ToastUtil.showToastShort(msg);
    }


}
