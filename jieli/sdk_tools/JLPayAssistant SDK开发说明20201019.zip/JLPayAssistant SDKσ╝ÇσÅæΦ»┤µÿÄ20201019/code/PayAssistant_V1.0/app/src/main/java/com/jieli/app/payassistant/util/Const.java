package com.jieli.app.payassistant.util;

import java.util.UUID;

/**
 * Des:
 * Author: Bob
 * Date:20-7-29
 * UpdateRemark:
 */
public final class Const {
    // SharedPreferences key name
    public static final String SP_ACCESS_TOKEN = "access_token";
    public static final String SP_USER_PWD = "user_password";

    public static final String KEY_CLIENT_ID = "client_id";

    // 订阅Topic
    public static final String SUB_TOPIC_PAYMENT = "iot/payassistant/%s/device/pub/payment";
    public static final String SUB_TOPIC_MESSAGE = "iot/payassistant/%s/device/pub/message";
    // 发布Topic
    public static final String PUB_TOPIC_PAYMENT = "iot/payassistant/%s/device/sub/payment";
    public static final String PUB_TOPIC_MESSAGE = "iot/payassistant/%s/device/sub/message";

    // type of message send to device
    public static final String MSG_TYPE_PAYMENT = "payment";
    public static final String MSG_TYPE_MESSAGE = "message";
    // Name of payment app
    public static final String APP_TYPE_ALIPAY = "alipay";
    public static final String APP_TYPE_WXPAY = "wxpay";


    public final  static String BLE_DISTRIBUTION_NETWORK_TEMPLATE="{\"ssid\":\"%1$s\",\"pass\":\"%2$s\"}";

    // Log settings
    public final static String LOG_SETTINGS = "log_settings";

    // 支付通知
    public final static String PAY_TITLE_WECHAT = "微信支付";
    public final static String PAY_TITLE_WECHAT1 = "微信收款助手";

    public final static String PAY_TITLE_ALI = "收钱码到账通知";
    public final static String PAY_TITLE_ALI2 = "你已成功收款";
    public final static String PAY_TITLE_ALI3 = "收钱码";
    public final static String PAY_TITLE_ALI4 = "收款通知";
}
