package com.jieli.app.payassistant.bean;

/**
 * Des:
 * Author: Bob
 * Date:20-7-28
 * UpdateRemark:
 */
public class TopicInfo {
}
