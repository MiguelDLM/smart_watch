package com.jieli.app.payassistant.http;

import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.jieli.app.payassistant.bean.BaseResponse;
import com.jieli.app.payassistant.bean.BondInfo;
import com.jieli.app.payassistant.bean.DeviceInfo;
import com.jieli.app.payassistant.bean.TokenInfo;
import com.jieli.app.payassistant.bean.UserInfo;
import com.jieli.app.payassistant.http.callback.IAction;
import com.jieli.app.payassistant.http.converter.GsonConverterFactory;
import com.jieli.app.payassistant.http.converter.StringConverterFactory;
import com.jieli.app.payassistant.util.HandlerUtil;
import com.jieli.app.payassistant.util.Jlog;

import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

import okhttp3.ConnectionPool;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

/**
 * Des:
 * Author: Bob
 * Date:20-7-29
 * UpdateRemark:
 */
public class HttpManager {
    private String tag = getClass().getSimpleName();

    private static class Singleton {
        private static final HttpManager instance = new HttpManager();
    }

    public static HttpManager getInstance() {
        return Singleton.instance;
    }

    private static final String BASE_URL = "http://log.jieliapp.com";
    private static final String LOGIN_TYPE = "user";
    private OkHttpClient httpClient;
    private IHttpApi mHttpApi;

    private OkHttpClient getDefaultOkHttpClient() {
//        HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor(new OkHttpLogging());
//        httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        return new OkHttpClient.Builder()
                .connectionPool(new ConnectionPool(5, 30L, TimeUnit.SECONDS))
//                .addInterceptor(httpLoggingInterceptor)
                .connectTimeout(5, TimeUnit.SECONDS)
                .readTimeout(5, TimeUnit.SECONDS)
                .writeTimeout(5, TimeUnit.SECONDS)
                .build();
    }

    public void create() {
        create(null, null);
    }

    public void create(Retrofit retrofit, OkHttpClient client) {
        if (client == null) {
            httpClient = getDefaultOkHttpClient();
        } else {
            httpClient = client;
        }

        Retrofit retrofit1;
        if (retrofit == null) {
            retrofit1 = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(StringConverterFactory.create())
                    .addConverterFactory(GsonConverterFactory.create())
                    .client(httpClient)
                    .build();
        } else {
            retrofit1 = retrofit;
        }
        mHttpApi = retrofit1.create(IHttpApi.class);
        Jlog.i(tag, "create http client");
    }

    /**
     * 分发成功结果的回调
     *
     * @param callback 回调
     * @param result   结果
     */
    private <T> void dispatchSuccessCallback(IAction<T> callback, T result) {
        if (callback == null) return;
        HandlerUtil.post(() -> callback.onSuccess(result));
    }

    /**
     * 分发错误的回调
     *
     * @param callback 回调
     * @param code     错误码值
     * @param msg      错误信息
     */
    private <T> void dispatchErrorCallback(IAction<T> callback, int code, String msg) {
        if (callback == null) return;
        HandlerUtil.post(() -> callback.onError(code, msg));
    }

    /**
     * 注册用户
     *
     * @param username 用户
     * @param password 密码
     * @param callback 结果回调
     */
    public void tryToRegister(String username, String password, final IAction<BaseResponse<UserInfo>> callback) {
        Objects.requireNonNull(httpClient);
        mHttpApi.register(username, password, LOGIN_TYPE).enqueue(new Callback<String>() {
            @Override
            public void onResponse(@NotNull Call<String> call, @NotNull Response<String> response) {
                if (!response.isSuccessful()) {
                    dispatchErrorCallback(callback, HttpCode.ERROR_NETWORK_RESPONSE, "response code : " + response.code());
                    return;
                }

                if (TextUtils.isEmpty(response.body())) {
                    dispatchErrorCallback(callback, HttpCode.ERROR_RESPONSE_DATA, "response body is null");
                    return;
                }
                Jlog.e(tag, "tryToRegister body=\n" + response.body());
                TypeToken<BaseResponse<UserInfo>> typeToken = new TypeToken<BaseResponse<UserInfo>>() {};
                BaseResponse<UserInfo> userInfo = new Gson().fromJson(response.body(), typeToken.getType());
                dispatchSuccessCallback(callback, userInfo);
            }

            @Override
            public void onFailure(@NotNull Call<String> call, @NotNull Throwable t) {
                Jlog.e(tag, "tryToRegister onFailure=" + t.getMessage());
                dispatchErrorCallback(callback, HttpCode.ERROR_NETWORK_EXCEPTION, t.getMessage());
            }
        });
    }

    /**
     * 登录
     *
     * @param username 用户名称
     * @param password 用户密码
     * @param callback 结果回调
     */
    public void tryToLogin(String username, String password, final IAction<BaseResponse<TokenInfo>> callback) {
        Jlog.i(tag, "try to login=" + username + ", " + password);
        Objects.requireNonNull(httpClient);
        mHttpApi.login(username, password, LOGIN_TYPE).enqueue(new Callback<String>() {
            @Override
            public void onResponse(@NotNull Call<String> call, @NotNull Response<String> response) {
                if (!response.isSuccessful()) {
                    dispatchErrorCallback(callback, HttpCode.ERROR_NETWORK_RESPONSE, "response code : " + response.code());
                    return;
                }

                if (TextUtils.isEmpty(response.body())) {
                    dispatchErrorCallback(callback, HttpCode.ERROR_RESPONSE_DATA, "response body is null");
                    return;
                }
//                Jlog.e(tag, "tryToLogin body=\n" + response.body());
                TypeToken<BaseResponse<TokenInfo>> typeToken = new TypeToken<BaseResponse<TokenInfo>>() {};
                BaseResponse<TokenInfo> baseResponse = new Gson().fromJson(response.body(), typeToken.getType());
                dispatchSuccessCallback(callback, baseResponse);
            }

            @Override
            public void onFailure(@NotNull Call<String> call, @NotNull Throwable t) {
                Jlog.e(tag, "tryToLogin onFailure=" + t.getMessage());
                dispatchErrorCallback(callback, HttpCode.ERROR_NETWORK_EXCEPTION, t.getMessage());
            }
        });
    }

    /**
     * 发现设备
     *
     * @param jwtToken 登录的用户token
     * @param callback 结果回调
     */
    public void tryToDiscovery(String jwtToken, final IAction<BaseResponse<DeviceInfo[]>> callback) {
        Objects.requireNonNull(httpClient);
        if (TextUtils.isEmpty(jwtToken)) {
            dispatchErrorCallback(callback, HttpCode.ERROR_PARAMS, "jwtToken : " + jwtToken);
            return;
        }
        mHttpApi.discovery(jwtToken).enqueue(new Callback<String>() {
            @Override
            public void onResponse(@NotNull Call<String> call, @NotNull Response<String> response) {
                if (!response.isSuccessful()) {
                    dispatchErrorCallback(callback, HttpCode.ERROR_NETWORK_RESPONSE, "response code : " + response.code());
                    return;
                }

                if (TextUtils.isEmpty(response.body())) {
                    dispatchErrorCallback(callback, HttpCode.ERROR_RESPONSE_DATA, "response body is null");
                    return;
                }

                Jlog.i(tag, "body=\n" + response.body());
                TypeToken<BaseResponse<DeviceInfo[]>> typeToken = new TypeToken<BaseResponse<DeviceInfo[]>>() {};
                BaseResponse<DeviceInfo[]> discoveryInfo = new Gson().fromJson(response.body(), typeToken.getType());
                dispatchSuccessCallback(callback, discoveryInfo);
            }

            @Override
            public void onFailure(@NotNull Call<String> call, @NotNull Throwable t) {
                dispatchErrorCallback(callback, HttpCode.ERROR_NETWORK_EXCEPTION, t.getMessage());
            }
        });
    }

    /**
     * 绑定设备
     *
     * @param jwtToken  登录的用户token
     * @param clientId  设备ClientID
     * @param bindToken 绑定验证码Token
     * @param callback  结果回调
     */
    public void tryToBind(String jwtToken, String clientId, String bindToken, final IAction<BaseResponse<Object>> callback) {
        Objects.requireNonNull(httpClient);
        if (TextUtils.isEmpty(jwtToken) || TextUtils.isEmpty(clientId) || TextUtils.isEmpty(bindToken)) {
            dispatchErrorCallback(callback, HttpCode.ERROR_PARAMS, "clientId : " + clientId + ", " + bindToken);
            return;
        }
        mHttpApi.bind(jwtToken, clientId, bindToken).enqueue(new Callback<String>() {
            @Override
            public void onResponse(@NotNull Call<String> call, @NotNull Response<String> response) {
                if (!response.isSuccessful()) {
                    dispatchErrorCallback(callback, HttpCode.ERROR_NETWORK_RESPONSE, "response code : " + response.code());
                    return;
                }

                if (TextUtils.isEmpty(response.body())) {
                    dispatchErrorCallback(callback, HttpCode.ERROR_RESPONSE_DATA, "response body is null");
                    return;
                }

                Jlog.i(tag, "body=\n" + response.body());
                TypeToken<BaseResponse<Object>> typeToken = new TypeToken<BaseResponse<Object>>() {};
                BaseResponse<Object> result = new Gson().fromJson(response.body(), typeToken.getType());
                dispatchSuccessCallback(callback, result);
            }

            @Override
            public void onFailure(@NotNull Call<String> call, @NotNull Throwable t) {
                dispatchErrorCallback(callback, HttpCode.ERROR_NETWORK_EXCEPTION, t.getMessage());
            }
        });
    }

    /**
     * 解除绑定设备
     *
     * @param jwtToken  登录的用户token
     * @param callback  结果回调
     */
    public void tryToUnbind(String jwtToken, final IAction<BaseResponse<Boolean>> callback) {
        Objects.requireNonNull(httpClient);
        if (TextUtils.isEmpty(jwtToken)) {
            dispatchErrorCallback(callback, HttpCode.ERROR_PARAMS, "jwtToken : " + jwtToken);
            return;
        }
        mHttpApi.unbind(jwtToken).enqueue(new Callback<String>() {
            @Override
            public void onResponse(@NotNull Call<String> call, @NotNull Response<String> response) {
                if (!response.isSuccessful()) {
                    dispatchErrorCallback(callback, HttpCode.ERROR_NETWORK_RESPONSE, "response code : " + response.code());
                    return;
                }

                if (TextUtils.isEmpty(response.body())) {
                    dispatchErrorCallback(callback, HttpCode.ERROR_RESPONSE_DATA, "response body is null");
                    return;
                }

                Jlog.i(tag, "body=\n" + response.body());
                TypeToken<BaseResponse<Boolean>> typeToken = new TypeToken<BaseResponse<Boolean>>() {};
                BaseResponse<Boolean> result = new Gson().fromJson(response.body(), typeToken.getType());
                dispatchSuccessCallback(callback, result);
            }

            @Override
            public void onFailure(@NotNull Call<String> call, @NotNull Throwable t) {
                dispatchErrorCallback(callback, HttpCode.ERROR_NETWORK_EXCEPTION, t.getMessage());
            }
        });
    }

    /**
     * 查询用户信息
     * @param accessToken 登录的用户token
     * @param callback 结果回调
     */
    public void tryToQuery(String accessToken, final IAction<BaseResponse<UserInfo>> callback) {
        Objects.requireNonNull(httpClient);
        if (TextUtils.isEmpty(accessToken)) {
            dispatchErrorCallback(callback, HttpCode.ERROR_PARAMS, "accessToken : " + accessToken);
            return;
        }

        mHttpApi.queryUserInfo(accessToken).enqueue(new Callback<String>() {
            @Override
            public void onResponse(@NotNull Call<String> call, @NotNull Response<String> response) {
                if (!response.isSuccessful()) {
                    dispatchErrorCallback(callback, HttpCode.ERROR_NETWORK_RESPONSE, "response code : " + response.code());
                    return;
                }

                if (TextUtils.isEmpty(response.body())) {
                    dispatchErrorCallback(callback, HttpCode.ERROR_RESPONSE_DATA, "response body is null");
                    return;
                }

                Jlog.e(tag, "tryToQuery body=\n" + response.body());
                TypeToken<BaseResponse<UserInfo>> typeToken = new TypeToken<BaseResponse<UserInfo>>() {};
                BaseResponse<UserInfo> userInfo = new Gson().fromJson(response.body(), typeToken.getType());
                dispatchSuccessCallback(callback, userInfo);
            }

            @Override
            public void onFailure(@NotNull Call<String> call, @NotNull Throwable t) {
                Jlog.e(tag, "tryToQuery onFailure=" + t.getMessage());
                dispatchErrorCallback(callback, HttpCode.ERROR_NETWORK_EXCEPTION, t.getMessage());
            }
        });
    }

    /**
     * 获取当前绑定设备
     * @param accessToken 登录的用户token
     * @param callback 结果回调
     */
    public void tryToRequestBondDevice(String accessToken, final IAction<BaseResponse<BondInfo>> callback) {
        Objects.requireNonNull(httpClient);
        if (TextUtils.isEmpty(accessToken)) {
            dispatchErrorCallback(callback, HttpCode.ERROR_PARAMS, "accessToken : " + accessToken);
            return;
        }

        mHttpApi.getBoundDevice(accessToken).enqueue(new Callback<String>() {
            @Override
            public void onResponse(@NotNull Call<String> call, @NotNull Response<String> response) {
                if (!response.isSuccessful()) {
                    dispatchErrorCallback(callback, HttpCode.ERROR_NETWORK_RESPONSE, "response code : " + response.code());
                    return;
                }

                if (TextUtils.isEmpty(response.body())) {
                    dispatchErrorCallback(callback, HttpCode.ERROR_RESPONSE_DATA, "response body is null");
                    return;
                }

                Jlog.i(tag, "tryToRequestBondDevice body=\n" + response.body());
                TypeToken<BaseResponse<BondInfo>> typeToken = new TypeToken<BaseResponse<BondInfo>>() {};
                BaseResponse<BondInfo> bondInfoBaseResponse = new Gson().fromJson(response.body(), typeToken.getType());
                dispatchSuccessCallback(callback, bondInfoBaseResponse);
            }

            @Override
            public void onFailure(@NotNull Call<String> call, @NotNull Throwable t) {
                Jlog.e(tag, "tryToRequestBondDevice onFailure=" + t.getMessage());
                dispatchErrorCallback(callback, HttpCode.ERROR_NETWORK_EXCEPTION, t.getMessage());
            }
        });
    }
}
