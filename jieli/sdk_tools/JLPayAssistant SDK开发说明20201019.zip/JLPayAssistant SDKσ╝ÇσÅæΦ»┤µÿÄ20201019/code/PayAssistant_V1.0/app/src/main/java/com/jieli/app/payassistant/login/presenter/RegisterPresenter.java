package com.jieli.app.payassistant.login.presenter;

import com.jieli.app.payassistant.bean.BaseResponse;
import com.jieli.app.payassistant.bean.UserInfo;
import com.jieli.app.payassistant.http.HttpCode;
import com.jieli.app.payassistant.http.HttpManager;
import com.jieli.app.payassistant.http.callback.IAction;
import com.jieli.app.payassistant.login.RegisterFragment;
import com.jieli.app.payassistant.ui.AbstractPresenter;
import com.jieli.app.payassistant.util.Jlog;

/**
 * Des:
 * Author: Bob
 * Date:20-7-28
 * UpdateRemark:
 */
public class RegisterPresenter extends AbstractPresenter<RegisterFragment> {

    public RegisterPresenter(RegisterFragment registerFragment) {
        super(registerFragment);
    }

    @Override
    public void onActivityCreated() {

    }

    @Override
    public void onStart() {

    }

    @Override
    public void onResume() {

    }

    @Override
    public void onPause() {

    }

    @Override
    public void onStop() {

    }

    @Override
    public void onDestroy() {

    }

    public void submit(String username, String password) {
        HttpManager.getInstance().tryToRegister(username, password, new IAction<BaseResponse<UserInfo>>() {
            @Override
            public void onSuccess(BaseResponse<UserInfo> response) {
                if (response.code == HttpCode.RESPONSE_SUCCESS) {
                    viewContext.onSubmitState(true);
                } else {
                    Jlog.e(tag, "msg=" + response.msg);
                    viewContext.onSubmitState(false);
                }
            }

            @Override
            public void onError(int code, String message) {
                viewContext.onSubmitState(false);
            }
        });
    }
}
