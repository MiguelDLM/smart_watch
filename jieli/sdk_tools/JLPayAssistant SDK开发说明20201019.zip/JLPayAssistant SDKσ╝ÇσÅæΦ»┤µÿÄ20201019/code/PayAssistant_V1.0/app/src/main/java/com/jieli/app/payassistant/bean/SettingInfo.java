package com.jieli.app.payassistant.bean;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 2020/9/24 8:15 PM
 * @desc :
 */
public class SettingInfo {
    private String text;
    private int index;
    private String tip;

    public SettingInfo(int index, String text,String tip) {
        this.index = index;
        this.text = text;
        this.tip=tip;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }


    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    public String getTip() {
        return tip;
    }
}
