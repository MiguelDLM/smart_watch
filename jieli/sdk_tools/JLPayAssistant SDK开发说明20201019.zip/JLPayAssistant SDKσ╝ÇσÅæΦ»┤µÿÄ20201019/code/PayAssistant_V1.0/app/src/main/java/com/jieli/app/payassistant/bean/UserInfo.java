package com.jieli.app.payassistant.bean;

import com.google.gson.annotations.SerializedName;

/**
 * Des:
 * Author: Bob
 * Date:20-7-30
 * UpdateRemark:
 */
public class UserInfo {
    @SerializedName("id")
    public String userId;
    @SerializedName("uuid")
    public String uuid;
    @SerializedName("nickname")
    public String nickname;
    @SerializedName("username")
    public String username;
    @SerializedName("password")
    public String password;
    @SerializedName("createTime")
    public String createTime;
    @SerializedName("updateTime")
    public String updateTime;
    @SerializedName("status")
    public Boolean status;
    @SerializedName("isDelete")
    public int isDelete;
    @SerializedName("explain")
    public String explain;

    @Override
    public String toString() {
        return "UserInfo{" +
                "userId='" + userId + '\'' +
                ", uuid='" + uuid + '\'' +
                ", nickname='" + nickname + '\'' +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", createTime='" + createTime + '\'' +
                ", updateTime='" + updateTime + '\'' +
                ", status=" + status +
                ", isDelete=" + isDelete +
                ", explain='" + explain + '\'' +
                '}';
    }
}
