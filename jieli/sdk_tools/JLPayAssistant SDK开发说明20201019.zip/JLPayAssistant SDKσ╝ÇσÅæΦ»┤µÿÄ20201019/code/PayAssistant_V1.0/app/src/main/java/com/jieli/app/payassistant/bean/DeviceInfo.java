package com.jieli.app.payassistant.bean;

import com.google.gson.annotations.SerializedName;

/**
 * Des:
 * Author: Bob
 * Date:20-7-29
 * UpdateRemark:
 */
public class DeviceInfo {
    @SerializedName("clientId")
    public String clientId;
    @SerializedName("deviceMac")
    public String deviceMac;
    @SerializedName("deviceId")
    public String deviceId;
    @SerializedName("bindToken")
    public String bindToken;
    @SerializedName("status")
    public boolean status;//true:已绑定，禁止再绑定，false：允许绑定

    @Override
    public String toString() {
        return "DiscoveryInfo{" +
                "clientId='" + clientId + '\'' +
                ", deviceMac='" + deviceMac + '\'' +
                ", deviceId='" + deviceId + '\'' +
                ", bindToken='" + bindToken + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
