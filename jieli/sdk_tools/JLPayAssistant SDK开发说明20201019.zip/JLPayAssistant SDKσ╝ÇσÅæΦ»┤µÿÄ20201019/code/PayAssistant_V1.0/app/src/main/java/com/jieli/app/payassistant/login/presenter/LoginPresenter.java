package com.jieli.app.payassistant.login.presenter;

import com.jieli.app.payassistant.bean.BaseResponse;
import com.jieli.app.payassistant.bean.TokenInfo;
import com.jieli.app.payassistant.http.HttpCode;
import com.jieli.app.payassistant.http.HttpManager;
import com.jieli.app.payassistant.http.callback.IAction;
import com.jieli.app.payassistant.login.LoginFragment;
import com.jieli.app.payassistant.ui.AbstractPresenter;
import com.jieli.app.payassistant.util.Const;
import com.jieli.app.payassistant.util.Jlog;
import com.jieli.app.payassistant.util.PreferencesHelper;

/**
 * Des:
 * Author: Bob
 * Date:20-7-28
 * UpdateRemark:
 */
public class LoginPresenter extends AbstractPresenter<LoginFragment> {

    public LoginPresenter(LoginFragment o) {
        super(o);
        HttpManager.getInstance().create();
    }

    @Override
    public void onActivityCreated() {
        Jlog.i(tag, "onActivityCreated");
    }

    @Override
    public void onStart() {
        Jlog.i(tag, "onStart");
    }

    @Override
    public void onResume() {
        Jlog.i(tag, "onResume");
    }

    @Override
    public void onPause() {
        Jlog.i(tag, "onPause");
    }

    @Override
    public void onStop() {
        Jlog.i(tag, "onStop");
    }

    @Override
    public void onDestroy() {
        Jlog.i(tag, "onDestroy");
    }

    public void login(String username, String password) {
        HttpManager.getInstance().tryToLogin(username, password, new IAction<BaseResponse<TokenInfo>>() {
            @Override
            public void onSuccess(BaseResponse<TokenInfo> response) {
                if (response.code == HttpCode.RESPONSE_SUCCESS) {
                    PreferencesHelper.putStringValue(mApplication, Const.SP_ACCESS_TOKEN, response.data.token);
                    PreferencesHelper.putStringValue(mApplication, Const.SP_USER_PWD, password);
                    viewContext.onLoginState(true);
                } else {
                    Jlog.e(tag, "msg:" + response.msg);
                    viewContext.onLoginState(false);
                }
            }

            @Override
            public void onError(int code, String message) {
                viewContext.onLoginState(false);
            }
        });
    }
}
