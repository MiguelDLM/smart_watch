package com.jieli.app.payassistant.home.presenter;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;
import android.text.TextUtils;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.PermissionChecker;

import com.google.gson.Gson;
import com.jieli.app.payassistant.BuildConfig;
import com.jieli.app.payassistant.R;
import com.jieli.app.payassistant.bean.BaseResponse;
import com.jieli.app.payassistant.bean.BondInfo;
import com.jieli.app.payassistant.bean.PayInfo;
import com.jieli.app.payassistant.bean.UserInfo;
import com.jieli.app.payassistant.home.HomeFragment;
import com.jieli.app.payassistant.http.HttpCode;
import com.jieli.app.payassistant.http.HttpManager;
import com.jieli.app.payassistant.http.callback.IAction;
import com.jieli.app.payassistant.mqtt.MyMqttService;
import com.jieli.app.payassistant.mqtt.core.MqttManager;
import com.jieli.app.payassistant.notification.AppNotificationListenerService;
import com.jieli.app.payassistant.ui.AbstractPresenter;
import com.jieli.app.payassistant.util.Actions;
import com.jieli.app.payassistant.util.CommonUtil;
import com.jieli.app.payassistant.util.Const;
import com.jieli.app.payassistant.util.Jlog;
import com.jieli.app.payassistant.util.PreferencesHelper;
import com.jieli.app.payassistant.util.StringUtil;
import com.jieli.app.payassistant.util.ToastUtil;

import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 2020/9/27 9:58 AM
 * @desc :
 */
public class HomePresenter extends AbstractPresenter<HomeFragment> {
    private String clientId = "";

    public HomePresenter(HomeFragment homeFragment) {
        super(homeFragment);
        String token = PreferencesHelper.getSharedPreferences(mApplication).getString(Const.SP_ACCESS_TOKEN, "");
        HttpManager.getInstance().tryToQuery(token, new IAction<BaseResponse<UserInfo>>() {
            @Override
            public void onSuccess(BaseResponse<UserInfo> response) {
                if (response.code == HttpCode.RESPONSE_SUCCESS) {
                    onQueryUserInfo(response.data);
                }
            }

            @Override
            public void onError(int code, String message) {
                ToastUtil.showToastShort(viewContext.getString(R.string.failure));
            }
        });
        mApplication.registerReceiver(receiver, new IntentFilter(Actions.ACTION_APP_NOTIFICATION));
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        mApplication.unregisterReceiver(receiver);
    }
    @Override
    public void onActivityCreated() {
        super.onActivityCreated();
        requestLocationPermission();
    }

    //根据包名打开设置页面
    public void openAppSetting(String packageName) {
        Intent intent = new Intent();
        intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        intent.setData(Uri.parse("package:" + packageName));
        viewContext.startActivity(intent);
    }


    //创建通知
    public void createNotification(String platform) {
        if (TextUtils.isEmpty(clientId)&&!BuildConfig.DEBUG) {
            viewContext.onShowMsg(mApplication.getString(R.string.msg_not_bond_device));
            return;
        }
        String money = new Random().nextInt(100) + "元";
        CommonUtil.createNotification(mApplication, money, platform);
    }

    //查询绑定的设备
    public void requestBondDevice() {
        String token = PreferencesHelper.getSharedPreferences(mApplication).getString(Const.SP_ACCESS_TOKEN, "");
        HttpManager.getInstance().tryToRequestBondDevice(token, new IAction<BaseResponse<BondInfo>>() {
            @Override
            public void onSuccess(BaseResponse<BondInfo> response) {
                if (response.code == HttpCode.RESPONSE_SUCCESS && response.data != null) {
                    viewContext.onRequestBond(response.data.clientId);
                    clientId = response.data.clientId;
                    subscribeTopic(clientId);
                } else {
                    onError(response.code, response.msg);
                }
            }

            @Override
            public void onError(int code, String message) {
                clientId = "";
                viewContext.onRequestBond(clientId);
            }
        });
    }



    private void requestLocationPermission() {
        Boolean locationPermission =
                (PermissionChecker.checkSelfPermission(mApplication, Manifest.permission.ACCESS_FINE_LOCATION) == PermissionChecker.PERMISSION_GRANTED)
                        &&
                        (PermissionChecker.checkSelfPermission(mApplication, Manifest.permission.ACCESS_COARSE_LOCATION) == PermissionChecker.PERMISSION_GRANTED);
        if (!locationPermission) {
            viewContext.requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, 0x01);
        }
    }

    /**
     * 用户信息获取到后启动mqtt服务
     *
     * @param userInfo 用户信息
     */
    private void onQueryUserInfo(UserInfo userInfo) {
        String password = PreferencesHelper.getSharedPreferences(mApplication).getString(Const.SP_USER_PWD, "");
        Intent intent = new Intent(mApplication, MyMqttService.class);
        intent.putExtra(MyMqttService.KEY_OP_MQTT, MyMqttService.OP_CREATE_MQTT);
        intent.putExtra("uuid", userInfo.uuid);
        intent.putExtra("username", userInfo.username);
        intent.putExtra("password", password);
        mApplication.startService(intent);
    }


    //打包msg
    private void packMessage(String appName, String content, float money) {
        PayInfo payInfo = new PayInfo();
        payInfo.type = Const.MSG_TYPE_PAYMENT;
        payInfo.app = appName;
        payInfo.payment = money;
        payInfo.msgid = StringUtil.getRandomString(12);
        payInfo.timestamp = System.currentTimeMillis();
        String json = new Gson().toJson(payInfo);
        Jlog.e(tag, "send msg to mqtt service -->json=\n" + json);
        viewContext.requireActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ToastUtil.showToastShort("拦截到通知："+content+"\t"+money);
            }
        });
        String topic = String.format(Const.PUB_TOPIC_PAYMENT, clientId);
        MqttManager.getInstance().publish(topic, json);
    }


    //根据clientId订阅mqtt Topic
    private void subscribeTopic(String clientId) {
        String[] topics = {String.format(Const.SUB_TOPIC_PAYMENT, clientId),
                String.format(Const.SUB_TOPIC_MESSAGE, clientId)};
        MqttManager.getInstance().subscribe(topics);

    }

    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (Actions.ACTION_APP_NOTIFICATION.equals(intent.getAction())) {
                String content = intent.getStringExtra(Actions.KEY_NOTIFICATION_CONTENT);
                String app = intent.getStringExtra(Actions.KEY_NOTIFICATION_APP);
                float money = intent.getFloatExtra(Actions.KEY_NOTIFICATION_MONEY, 0f);
                packMessage(app, content, money);
            }
        }
    };


    public void unbindDevice() {
        String token = PreferencesHelper.getSharedPreferences(mApplication).getString(Const.SP_ACCESS_TOKEN, "");
        HttpManager.getInstance().tryToUnbind(token, new IAction<BaseResponse<Boolean>>() {
            @Override
            public void onSuccess(BaseResponse<Boolean> response) {
                if (response.code == HttpCode.RESPONSE_SUCCESS) {
                    requestBondDevice();
                } else {
                    onError(response.code, response.msg);
                }
            }

            @Override
            public void onError(int code, String message) {
                viewContext.onShowMsg(mApplication.getString(R.string.msg_unbind_fail, "code = " + code + "\tmsg = " + message));

            }
        });
    }
}
