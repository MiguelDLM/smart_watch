package com.jieli.app.payassistant.bean;

import com.google.gson.annotations.SerializedName;

import org.jetbrains.annotations.NotNull;

/**
 * Des:主要用于将非支付信息发送给设备
 * Author: Bob
 * Date:20-8-1
 * UpdateRemark:
 */
public class MessageInfo {
    @SerializedName("type")
    public String type; // payment, message
    @SerializedName("title")
    public String title; // APP应用名称
    @SerializedName("content")
    public String content;
    @SerializedName("msgid")
    public String msgid;
    @SerializedName("ts")
    public long timestamp;

    @NotNull
    @Override
    public String toString() {
        return "MessageInfo{" +
                "type='" + type + '\'' +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", msgid='" + msgid + '\'' +
                ", timestamp=" + timestamp +
                '}';
    }
}
