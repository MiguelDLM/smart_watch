package com.jieli.app.payassistant.mqtt.core;

/**
 * Des:
 * Author: Bob
 * Date:20-7-28
 * UpdateRemark:
 */
public interface IObserver<T> {
    void onCommand(T t);
}
