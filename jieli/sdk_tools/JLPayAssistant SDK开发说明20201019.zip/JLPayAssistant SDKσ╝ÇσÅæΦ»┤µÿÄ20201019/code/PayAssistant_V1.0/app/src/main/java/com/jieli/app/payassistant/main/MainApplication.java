package com.jieli.app.payassistant.main;

import android.app.Application;

import com.jieli.app.payassistant.util.ToastUtil;
import com.jieli.app.payassistant.util.WifiHelper;
import com.jieli.lib.payassistant.BluetoothClient;

/**
 * Des:
 * Author: Bob
 * Date:20-7-28
 * UpdateRemark:
 */
public class MainApplication extends Application {
    private static MainApplication mApplication;

    /**
     * 初始化参数
     */
    @Override
    public void onCreate() {
        super.onCreate();
        mApplication = this;
        ToastUtil.init(this);
        WifiHelper.init(this);
    }

    public static synchronized MainApplication getApplication() {
        return mApplication;
    }
}
