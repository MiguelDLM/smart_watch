package com.jieli.app.payassistant.util;

import java.util.Locale;
import java.util.Random;

/**
 * Des:
 * Author: Bob
 * Date:20-8-1
 * UpdateRemark:
 */
public final class StringUtil {
    public static String getRandomString(int length) {
        String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            int number = random.nextInt(62);
            sb.append(str.charAt(number));
        }
        return sb.toString();
    }

    public static String byteToHexString(byte[] b) {
        return byteToHexString(b, b.length);
    }

    public static String byteToHexString(byte[] b, int len) {
        char[] mChars = "0123456789ABCDEF".toCharArray();
        if (b == null || b.length < len) return "";
        StringBuilder sb = new StringBuilder();
        for (int n = 0; n < len; n++) {
            sb.append(mChars[(b[n] & 0xFF) >> 4]);
            sb.append(mChars[b[n] & 0x0F]);
        }
        return sb.toString().trim().toUpperCase(Locale.US);
    }
}
