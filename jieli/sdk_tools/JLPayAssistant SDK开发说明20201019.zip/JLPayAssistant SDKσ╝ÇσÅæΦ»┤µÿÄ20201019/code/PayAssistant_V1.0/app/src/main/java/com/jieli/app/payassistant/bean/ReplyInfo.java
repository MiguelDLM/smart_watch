package com.jieli.app.payassistant.bean;

import com.google.gson.annotations.SerializedName;

import org.jetbrains.annotations.NotNull;

/**
 * Des: 设备端收到支付信息后，回复的信息
 * Author: Bob
 * Date:20-7-31
 * UpdateRemark:
 */
public class ReplyInfo {
    @SerializedName("msgid")
    public String messageId;
    @SerializedName("status")
    public boolean status;
    @SerializedName("ts")
    public long timestamp;

    @NotNull
    @Override
    public String toString() {
        return "ReplyInfo{" +
                "messageId='" + messageId + '\'' +
                ", status=" + status +
                ", timestamp=" + timestamp +
                '}';
    }
}
