package com.jieli.app.payassistant.ui.adapter;

import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.jieli.app.payassistant.R;
import com.jieli.app.payassistant.bean.BleScanInfo;
import com.jieli.app.payassistant.bean.SettingInfo;

import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 2020/8/27 5:01 PM
 * @desc :
 */
public class SettingItemAdapter extends BaseQuickAdapter<SettingInfo, BaseViewHolder> {
    public SettingItemAdapter() {
        super(R.layout.item_setting);
    }

    @Override
    protected void convert(@NotNull BaseViewHolder holder, SettingInfo settingInfo) {
        TextView textView = holder.itemView.findViewById(R.id.tv_setting_name);
        textView.setText(settingInfo.getText());
        holder.setText(R.id.tv_setting_tip,settingInfo.getTip());
    }



}
