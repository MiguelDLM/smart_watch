package com.jieli.app.payassistant.bean;

import com.google.gson.annotations.SerializedName;

/**
 * Des:蓝牙配网后，设备发现返回的信息
 * Author: Bob
 * Date:20-9-10
 * UpdateRemark:
 */
public final class BtDevInfo {
    @SerializedName("clientid")
    public String clientId;
    @SerializedName("username")
    public String username;
    @SerializedName("bind_token")
    public String bindToken;

    @Override
    public String toString() {
        return "BtDevInfo{" +
                "clientId='" + clientId + '\'' +
                ", username='" + username + '\'' +
                ", bindToken='" + bindToken + '\'' +
                '}';
    }
}
