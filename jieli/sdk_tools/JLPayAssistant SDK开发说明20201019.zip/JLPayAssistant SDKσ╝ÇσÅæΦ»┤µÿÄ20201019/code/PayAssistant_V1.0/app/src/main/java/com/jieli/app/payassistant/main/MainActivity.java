package com.jieli.app.payassistant.main;

import android.app.AlertDialog;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.IBinder;

import androidx.core.app.NotificationManagerCompat;
import androidx.fragment.app.Fragment;

import com.jieli.app.payassistant.R;

import com.jieli.app.payassistant.home.HomeFragment;
import com.jieli.app.payassistant.login.LoginFragment;
import com.jieli.app.payassistant.login.RegisterFragment;
import com.jieli.app.payassistant.main.presenter.MainPresenter;
import com.jieli.app.payassistant.notification.AppNotificationListenerService;
import com.jieli.app.payassistant.settings.AboutFragment;
import com.jieli.app.payassistant.ui.BaseActivity;
import com.jieli.app.payassistant.ui.BaseFragment;
import com.jieli.app.payassistant.util.CommonUtil;
import com.jieli.app.payassistant.util.Const;
import com.jieli.app.payassistant.util.HandlerUtil;
import com.jieli.app.payassistant.util.Jlog;

public class MainActivity extends BaseActivity implements ServiceConnection {
    private BaseFragment mLoginFragment;
    private MainPresenter mPresenter;
    private AlertDialog alertDialog;
    private final int REQUEST_NOTIFICATION_LISTENER_SETTINGS = 0x10;
    private Intent mService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (mPresenter == null) {
            mPresenter = new MainPresenter(this);
            getLifecycle().addObserver(mPresenter);
        }
        if (CommonUtil.isNotificationEnabled(getApplicationContext())) {
          startPayService();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (alertDialog != null && alertDialog.isShowing()) {
            alertDialog.dismiss();
            alertDialog = null;
        }
        if (mService != null) {
            mApplication.unbindService(this);
        }
    }

    @Override
    public void onBackPressed() {
        BaseFragment fragment = (BaseFragment) getSupportFragmentManager().findFragmentById(R.id.main_container);
        if (fragment instanceof LoginFragment || fragment instanceof HomeFragment) {
            finish();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        mService = null;
        if (requestCode == REQUEST_NOTIFICATION_LISTENER_SETTINGS) {
            if (mPresenter.enableNotification()) {
                Jlog.w(tag, "isNotificationEnabled!!");
                startPayService();
            } else {
                Jlog.i(tag, "Fail to open notification permission");
                showNotificationDialog();
            }
        } else {
            Jlog.e(tag, "onActivityResult: requestCode=" + requestCode);
        }
        Jlog.i(tag, "startService " + mService);
        if (mService != null) {
            mApplication.startService(mService);
        }
    }

    /**
     * 开始主界面的工作
     */
    public void startWorking() {
        if (mLoginFragment == null) {
            mLoginFragment = LoginFragment.newInstance();
            switchFragment(LoginFragment.class);
        }
        if (!mPresenter.enableNotification()) {
            HandlerUtil.postDelayed(this::showNotificationDialog, 500);
        } else if (NotificationManagerCompat.from(mApplication).areNotificationsEnabled()) {
            Jlog.i(tag, "isNotificationEnabled!!!");
        }


    }

    /**
     * 开启通知管理权限对话框
     */
    private void showNotificationDialog() {
        alertDialog = new AlertDialog.Builder(this).setIcon(R.mipmap.ic_launcher)
                .setTitle(getString(android.R.string.dialog_alert_title))
                .setMessage(getString(R.string.notification_permission))
                .setCancelable(false)
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    dialog.dismiss();
                    alertDialog = null;
                    Intent intent = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
                    startActivityForResult(intent, REQUEST_NOTIFICATION_LISTENER_SETTINGS);
                })
                .create();
        alertDialog.show();
    }

    public <T extends Fragment> void switchFragment(Class<T> clazz) {
        switchFragment(clazz, null);
    }

    public <T extends Fragment> void switchFragment(Class<T> clazz, Bundle bundle) {
        Fragment fragment = getSupportFragmentManager().findFragmentByTag(clazz.getCanonicalName());
        if (fragment == null) {
            try {
                fragment = clazz.newInstance();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (fragment != null) {
            if (bundle != null) {
                fragment.setArguments(bundle);
            }
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.main_container, fragment, fragment.getClass().getCanonicalName())
                    .addToBackStack(null)
                    .commitAllowingStateLoss();
        }
    }



    @Override
    public void onServiceConnected(ComponentName name, IBinder service) {
        Jlog.i(tag, "onServiceConnected");
    }

    @Override
    public void onServiceDisconnected(ComponentName name) {

    }


    private void startPayService() {
        toggleNotification();
        mService = new Intent(mApplication, AppNotificationListenerService.class);
//        mApplication.stopService(mService);
        mApplication.startService(mService);
        mApplication.bindService(mService, this, Service.BIND_AUTO_CREATE);

    }


    private void toggleNotification() {
        PackageManager pm = mApplication.getPackageManager();
        pm.setComponentEnabledSetting(new ComponentName(mApplication, AppNotificationListenerService.class)
                , PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);

        pm.setComponentEnabledSetting(new ComponentName(mApplication, AppNotificationListenerService.class)
                , PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
    }
}