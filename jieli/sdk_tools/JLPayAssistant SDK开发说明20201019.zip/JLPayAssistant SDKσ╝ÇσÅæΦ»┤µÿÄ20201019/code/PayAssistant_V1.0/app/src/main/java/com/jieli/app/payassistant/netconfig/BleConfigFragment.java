package com.jieli.app.payassistant.netconfig;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.jieli.app.payassistant.R;
import com.jieli.app.payassistant.netconfig.presenter.BleConfigPresenter;
import com.jieli.app.payassistant.ui.BaseFragment;
import com.jieli.app.payassistant.util.Jlog;
import com.jieli.app.payassistant.util.PreferencesHelper;
import com.jieli.app.payassistant.util.ToastUtil;
import com.jieli.app.payassistant.util.WifiHelper;


public class BleConfigFragment extends BaseFragment {


    private BleConfigPresenter mPresenter;
    private AlertDialog dialog;
    private String TAG = getClass().getSimpleName();
    private TextView tvLog;
    private EditText etSsid;
    private EditText etPass;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPresenter = new BleConfigPresenter(this);
        requireActivity().getLifecycle().addObserver(mPresenter);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_ble_config, container, false);
        final String wifiName = WifiHelper.getInstance().getCurrentConnectedSsid(mApplication);
        etSsid = root.findViewById(R.id.et_wifi_ssid);
        etPass = root.findViewById(R.id.et_wifi_pass);
        etSsid.setText(wifiName);
        root.findViewById(R.id.btn_config).setOnClickListener(v -> {
            String ssid = etSsid.getText().toString();
            String pass = etPass.getText().toString();
            if (TextUtils.isEmpty(ssid)) {
                ToastUtil.showToastShort(getString(R.string.tip_input_wifi_ssid));
            } else if (TextUtils.isEmpty(pass)) {
                ToastUtil.showToastShort(getString(R.string.tip_input_pass));
            } else {
                mPresenter.config(ssid, pass);
            }
        });

        tvLog = root.findViewById(R.id.tv_ble_config_log);
        String log = PreferencesHelper.getSharedPreferences(requireContext()).getString("ble_log", "");
        appendLog(log);
        root.findViewById(R.id.tv_ble_config_log_title).setOnClickListener(v -> tvLog.setText(""));
        return root;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (mPresenter != null) {
            mPresenter.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (mPresenter != null) {
            mPresenter.onActivityResult(requestCode, resultCode, data);
        }
    }

    public void onSuccess(String clientId) {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
        Jlog.i(TAG, "配网成功:");
        appendLog(getString(R.string.msg_ble_config_success));
        requireActivity().onBackPressed();

    }

    public void onFailure(String msg) {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
        Jlog.i(TAG, "配网失败:" + msg);
        requireActivity().runOnUiThread(() -> {
            ToastUtil.showToastShort(msg);
            appendLog(msg);
        });

    }


    public void onProgressMsg(String msg) {
        requireActivity().runOnUiThread(() -> {
            createDialog();
            Jlog.i(TAG, "onProgressMsg:" + msg);
            appendLog(msg);
            dialog.setMessage(msg);
            if (!dialog.isShowing()) {
                dialog.show();
            }
        });
    }

    @Override
    public void onDestroyView() {
        PreferencesHelper.putStringValue(requireContext(), "ble_log", tvLog.getText().toString());
        super.onDestroyView();
    }

    private void createDialog() {
        if (dialog == null) {
            dialog = new AlertDialog.Builder(requireContext())
                    .setTitle(getString(R.string.app_name))
                    .setCancelable(false)
                    .create();
        }
    }

    private void appendLog(String msg) {
        String log = tvLog.getText() == null ? "" : tvLog.getText() + "\n" + msg;
        requireActivity().runOnUiThread(() -> tvLog.setText(log.trim()));

    }


}