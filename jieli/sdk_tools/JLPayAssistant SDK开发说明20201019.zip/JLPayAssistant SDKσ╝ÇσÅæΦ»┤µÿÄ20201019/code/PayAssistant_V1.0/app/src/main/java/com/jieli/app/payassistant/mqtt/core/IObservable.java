package com.jieli.app.payassistant.mqtt.core;

/**
 * Des:
 * Author: Bob
 * Date:20-7-28
 * UpdateRemark:
 */
public interface IObservable<T> {
    void register(IObserver<T> observer);
    void unregister(IObserver<T> observer);
    void unregisterAll();
    void notify(T t);
}
