package com.jieli.app.payassistant.bean;

import com.google.gson.annotations.SerializedName;

import org.jetbrains.annotations.NotNull;

/**
 * Des: 支付信息，最终发给设备端
 * Author: Bob
 * Date:20-8-1
 * UpdateRemark:
 */
public class PayInfo {
    @SerializedName("type")
    public String type; // payment, message
    @SerializedName("application")
    public String app; // alipay, wxpay
    @SerializedName("amount")
    public float payment;
    @SerializedName("msgid")
    public String msgid;
    @SerializedName("ts")
    public long timestamp;

    @NotNull
    @Override
    public String toString() {
        return "PayInfo{" +
                "type='" + type + '\'' +
                ", app='" + app + '\'' +
                ", payment=" + payment +
                ", msgid='" + msgid + '\'' +
                ", timestamp=" + timestamp +
                '}';
    }
}
