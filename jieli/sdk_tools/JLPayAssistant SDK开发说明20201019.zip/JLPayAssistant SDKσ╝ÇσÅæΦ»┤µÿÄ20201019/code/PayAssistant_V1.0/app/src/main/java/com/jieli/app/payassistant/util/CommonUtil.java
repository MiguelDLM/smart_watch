package com.jieli.app.payassistant.util;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.text.TextUtils;

import androidx.core.app.NotificationCompat;

import com.jieli.app.payassistant.R;
import com.jieli.app.payassistant.main.MainActivity;

import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Des:
 * Author: Bob
 * Date:20-9-16
 * UpdateRemark:
 */
public class CommonUtil {
    private static final String tag = "CommonUtil";
    private static final String ENABLED_NOTIFICATION_LISTENERS = "enabled_notification_listeners";

    public static boolean isNotificationEnabled(Context context) {
        String pkgName = context.getPackageName();
        final String flat = Settings.Secure.getString(context.getContentResolver(), ENABLED_NOTIFICATION_LISTENERS);
        if (!TextUtils.isEmpty(flat)) {
            final String[] names = flat.split(":");
//            Jlog.i(tag, "flat " + flat);
            for (String name : names) {
                final ComponentName cn = ComponentName.unflattenFromString(name);
                if (cn != null) {
                    if (TextUtils.equals(pkgName, cn.getPackageName())) {
                        Jlog.w(tag, "Found:" + pkgName);
                        return true;
                    }
                }
            }
        }
        return false;
    }


    public static void openStart(Context context) {

        Intent intent = new Intent();
        if (RomUtil.isEmui()) {//华为
            ComponentName componentName = new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity");
            intent.setComponent(componentName);
        } else if (RomUtil.isMiui()) {//小米
            ComponentName componentName = new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity");
            intent.setComponent(componentName);
        } else if (RomUtil.isOppo()) {//oppo
            ComponentName componentName = null;
            if (Build.VERSION.SDK_INT >= 26) {
                componentName = new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity");
            } else {
                componentName = new ComponentName("com.color.safecenter", "com.color.safecenter.permission.startup.StartupAppListActivity");
            }
            intent.setComponent(componentName);
            //上面的代码不管用了，因为oppo手机也是手机管家进行自启动管理
        } else if (RomUtil.isVivo()) {//Vivo
            ComponentName componentName = null;
            if (Build.VERSION.SDK_INT >= 26) {
                componentName = new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.PurviewTabActivity");
            } else {
                componentName = new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.SoftwareManagerActivity");
            }
            intent.setComponent(componentName);
        } else if (RomUtil.isFlyme()) {//魅族
            // 通过测试，发现魅族是真恶心，也是够了，之前版本还能查看到关于设置自启动这一界面，
            // 系统更新之后，完全找不到了，心里默默Fuck！
            // 针对魅族，我们只能通过魅族内置手机管家去设置自启动，
            // 所以我在这里直接跳转到魅族内置手机管家界面，具体结果请看图
            ComponentName componentName = ComponentName.unflattenFromString("com.meizu.safe" +
                    "/.permission.PermissionMainActivity");
            intent.setComponent(componentName);
        } else {
            // 以上只是市面上主流机型，由于公司你懂的，所以很不容易才凑齐以上设备
            // 针对于其他设备，我们只能调整当前系统app查看详情界面
            // 在此根据用户手机当前版本跳转系统设置界面
            if (Build.VERSION.SDK_INT >= 9) {
                intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
                intent.setData(Uri.fromParts("package", context.getPackageName(), null));
            } else if (Build.VERSION.SDK_INT <= 8) {
                intent.setAction(Intent.ACTION_VIEW);
                intent.setClassName("com.android.settings",
                        "com.android.settings.InstalledAppDetails");
                intent.putExtra("com.android.settings.ApplicationPkgName",
                        context.getPackageName());
            }
            intent = new Intent(Settings.ACTION_SETTINGS);
        }
        try {
            context.startActivity(intent);
        } catch (Exception e) {//抛出异常就直接打开设置页面
            Intent intent1 = new Intent(Settings.ACTION_SETTINGS);
            context.startActivity(intent1);
        }
    }


    /**
     * 模拟收款通知
     */
    private static int notificationId = 0;

    public static void createNotification(Context context, String money, String platform) {
        Jlog.i(tag, "createNotification platform = " + platform + "\tmoney = " + money);
        context = context.getApplicationContext();
        NotificationManager notificationManager
                = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel channel;
        Notification.Builder builder;
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            channel = new NotificationChannel(context.getPackageName(),
                    context.getString(R.string.app_name), NotificationManager.IMPORTANCE_HIGH);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
            builder = new Notification.Builder(context, context.getPackageName());
        } else {
            builder = new Notification.Builder(context);
        }

        Intent intent = new Intent(context, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0,
                intent, PendingIntent.FLAG_CANCEL_CURRENT);
        builder.setContentIntent(pendingIntent);
        Notification notification = builder
                .setContentIntent(pendingIntent)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentText("收到来自xxx的" + money)
                .setContentTitle(platform)
                .setPriority(Notification.PRIORITY_MAX)
                .build();

        int id = notificationId++;
        notificationManager.notify(id, notification);
    }

    public static float getFloatFromString(String content) {
        Pattern pattern = Pattern.compile("[0-9]+(\\.[0-9]+)?");

        Matcher m = pattern.matcher(content);
        String value = "0.0";
        while (m.find()) {
            value = m.group();
            Jlog.w(tag, "value=" + Float.parseFloat(value));
        }
        return Float.parseFloat(value);
    }
}
