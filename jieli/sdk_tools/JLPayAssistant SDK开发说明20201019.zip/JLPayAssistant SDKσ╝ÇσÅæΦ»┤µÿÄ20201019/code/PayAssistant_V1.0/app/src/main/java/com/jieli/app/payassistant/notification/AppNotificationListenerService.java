package com.jieli.app.payassistant.notification;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;

import com.jieli.app.payassistant.util.Actions;
import com.jieli.app.payassistant.util.CommonUtil;
import com.jieli.app.payassistant.util.Const;
import com.jieli.app.payassistant.util.Jlog;
import com.jieli.app.payassistant.util.LogRecorder;
import com.jieli.app.payassistant.util.PreferencesHelper;
import com.jieli.app.payassistant.util.ToastUtil;

import java.io.File;

import static com.jieli.app.payassistant.util.Actions.ACTION_NOTIFICATION_SERVICE_CONNECTED;

/**
 * Des:
 * Author: Bob
 * Date:20-7-15
 * UpdateRemark:
 */
public final class AppNotificationListenerService extends NotificationListenerService {
    private String TAG = getClass().getSimpleName();

    @Override
    public void onCreate() {
        SharedPreferences sp = PreferencesHelper.getSharedPreferences(this);
        boolean isOpen = sp.getBoolean(Const.LOG_SETTINGS, false);
        if (isOpen) openOrCloseLog();
        Jlog.e(TAG, "onCreate");

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Jlog.e(TAG, "onStartCommand");
        return super.onStartCommand(intent, flags, startId);

    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        Jlog.e(TAG, "onNotificationPosted  package name is -->" + sbn.getPackageName());
        Jlog.e(TAG, "onNotificationPosted  notify is -->" + sbn.getNotification());
        String app;
        if ("com.eg.android.AlipayGphone".equals(sbn.getPackageName())) {
            handleAliNotify(sbn.getNotification());
        } else if ("com.tencent.mm".equals(sbn.getPackageName())) {
            handleWeChatNotify(sbn.getNotification());
        } else if (getPackageName().equals(sbn.getPackageName())) {
            handleTestNotify(sbn.getNotification());
        } else if ("com.jieli.paytest".equals(sbn.getPackageName())) {
            handleTestNotify(sbn.getNotification());
        }else {
            Jlog.e(TAG, "onNotificationPosted: Not support=" + sbn.getPackageName());
        }
    }

    //处理微信的通知
    private void handleWeChatNotify(Notification notification) {
        if (notification == null || notification.extras == null) {
            return;
        }
        // 获取通知标题
        String title = notification.extras.getString(Notification.EXTRA_TITLE, "");
        // 获取通知内容
        String content = notification.extras.getString(Notification.EXTRA_TEXT, "");

        Jlog.i(TAG, "title: " + title + ", content: " + content);
        if (!title.contains(Const.PAY_TITLE_WECHAT)&&!title.contains(Const.PAY_TITLE_WECHAT1)) {
            Jlog.w(TAG, "Not a payment message");
            return;
        }

        float money = CommonUtil.getFloatFromString(content);
        if (money > 0) {
            sendAppNotification(Const.APP_TYPE_WXPAY, content, money);
        } else {
            Jlog.w(TAG, "money is error");
        }
    }


    //处理支付宝的通知
    private void handleAliNotify(Notification notification) {
        if (notification == null || notification.extras == null) {
            return;
        }
        // 获取通知标题
        String title = notification.extras.getString(Notification.EXTRA_TITLE, "");
        // 获取通知内容
        String content = notification.extras.getString(Notification.EXTRA_TEXT, "");
        Jlog.i(TAG, "title: " + title + ", content: " + content);
        float money = 0;

        if (title.contains(Const.PAY_TITLE_ALI)) {
            money = CommonUtil.getFloatFromString(content);
        } else if (title.contains(Const.PAY_TITLE_ALI2)) {
            money = CommonUtil.getFloatFromString(title);
            content = title;
        }  else if (title.contains(Const.PAY_TITLE_ALI3)) {
            money = CommonUtil.getFloatFromString(content);
        } else if (title.contains(Const.PAY_TITLE_ALI4)) {
            money = CommonUtil.getFloatFromString(content);
        }else {
            Jlog.i(TAG, "not payment notify");
            return;
        }
        if (money > 0) {
            sendAppNotification(Const.APP_TYPE_ALIPAY, content, money);
        } else {
            Jlog.w(TAG, "money is error");
        }

    }

    //处理测试的通知
    private void handleTestNotify(Notification notification) {
        if (notification == null || notification.extras == null) {
            ToastUtil.showToastShort("handleTestNotify error 1：" );
            return;
        }
        // 获取通知标题
        String title = notification.extras.getString(Notification.EXTRA_TITLE, "");
        // 获取通知内容
        String content = notification.extras.getString(Notification.EXTRA_TEXT, "");
        Jlog.i(TAG, "title: " + title + ", content: " + content);
        float money = CommonUtil.getFloatFromString(content);
        if (money > 0) {
            sendAppNotification(title.equals(Const.PAY_TITLE_WECHAT) ? Const.APP_TYPE_WXPAY : Const.APP_TYPE_ALIPAY, content, money);
        } else {
            Jlog.w(TAG, "money is error");
            ToastUtil.showToastShort("handleTestNotify error 2：" );
        }
    }


    private void sendAppNotification(String app, String content, float money) {
        Intent intent = new Intent(Actions.ACTION_APP_NOTIFICATION);
        intent.putExtra(Actions.KEY_NOTIFICATION_MONEY, money);
        intent.putExtra(Actions.KEY_NOTIFICATION_CONTENT, content);
        intent.putExtra(Actions.KEY_NOTIFICATION_APP, app);
        sendBroadcast(intent);
    }


    @Override
    public void onDestroy() {
        Jlog.w(TAG, "onDestroy");
        if (mLogRecorder != null) {
            mLogRecorder.stop();
            mLogRecorder = null;
        }
    }

    private LogRecorder mLogRecorder;

    private void openOrCloseLog() {
        String logPath;
        File file = getExternalFilesDir(null);
        if (file != null) {
            logPath = file.getAbsolutePath() + "/logs";
        } else {
            Jlog.e(TAG, "Open or close log failed");
            return;
        }
        if (mLogRecorder != null) {
            if (mLogRecorder.isRunning()) {
                mLogRecorder.stop();
                mLogRecorder = null;
            }

            file = new File(logPath);
            if (file.exists() && !LogRecorder.deleteFile(file)) {
                Jlog.e(TAG, "Delete failed:" + logPath);
            }
        } else {
            mLogRecorder = new LogRecorder.Builder(this)
                    .setLogFolderPath(logPath)
                    .setLogFileNamePrefix("log")
                    .setLogFileSizeLimitation(2 * 1024)
                    .setLogLevel(4)
                    .addLogFilterTag(null)
                    .setPID(android.os.Process.myPid())
                    .build();
            mLogRecorder.start();
        }
    }
}
