package com.jieli.app.payassistant.bean;

import com.google.gson.annotations.SerializedName;

import org.jetbrains.annotations.NotNull;

/**
 * Des:
 * Author: Bob
 * Date:20-7-29
 * UpdateRemark:
 */
public class TokenInfo {

    @SerializedName("access_token")
    public String token;
    @SerializedName("token_type")
    public String type;
    @SerializedName("expires_in")
    public int expiresIn;

    @NotNull
    @Override
    public String toString() {
        return "TokenInfo{" +
                "token='" + token + '\'' +
                ", type='" + type + '\'' +
                ", expiresIn=" + expiresIn +
                '}';
    }


}
