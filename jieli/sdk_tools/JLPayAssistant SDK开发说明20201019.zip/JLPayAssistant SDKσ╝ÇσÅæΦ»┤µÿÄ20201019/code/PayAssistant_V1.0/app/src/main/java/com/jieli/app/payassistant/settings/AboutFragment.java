package com.jieli.app.payassistant.settings;

import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.jieli.app.payassistant.R;
import com.jieli.app.payassistant.ui.BaseFragment;
import com.jieli.app.payassistant.ui.adapter.AboutAdapter;
import com.jieli.app.payassistant.util.Const;
import com.jieli.app.payassistant.util.HandlerUtil;
import com.jieli.app.payassistant.util.PreferencesHelper;
import com.jieli.app.payassistant.util.ToastUtil;

/**
 * Des:
 * Author: Bob
 * Date:20-8-4
 * UpdateRemark:
 */
public class AboutFragment extends BaseFragment {
    public static AboutFragment newInstance() {
        return new AboutFragment();
    }

    private RecyclerView rvListView;
    private AboutAdapter aboutAdapter;
    private TextView tvAppVersion;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_about, container, false);
        rvListView = view.findViewById(R.id.rv_about_list);
        tvAppVersion = view.findViewById(R.id.tv_icon_version);
        tvAppVersion.setOnClickListener(mLogOnClickListener);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        rvListView.setLayoutManager(new StaggeredGridLayoutManager(1, RecyclerView.VERTICAL));
        PackageManager pm = mApplication.getPackageManager();
        try {
            String version = pm.getPackageInfo(mApplication.getPackageName(), 0).versionName;
            tvAppVersion.setText(version);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
    }

    private long mLogDebugClickTimes;
    private int mLogDebugCount = 0;
    private static final int TIME_INTERVAL = 2000;
    private final View.OnClickListener mLogOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (mLogDebugClickTimes + TIME_INTERVAL > System.currentTimeMillis()) {
                mLogDebugCount++;
                if (mLogDebugCount == 4) {
                    SharedPreferences sp = PreferencesHelper.getSharedPreferences(mApplication);
                    boolean currentState = sp.getBoolean(Const.LOG_SETTINGS, false);
                    if (currentState) {
                        ToastUtil.showToastLong(("Saving log close"));
                    } else {
                        ToastUtil.showToastLong(("Saving log open"));
                    }
                    PreferencesHelper.putBooleanValue(mApplication, Const.LOG_SETTINGS, !currentState);

                    HandlerUtil.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            mLogDebugCount = 0;
                        }
                    }, 2000);
                }
            } else {
                mLogDebugCount = 0;
            }
            mLogDebugClickTimes = System.currentTimeMillis();
        }
    };
}
