package com.jieli.app.payassistant.ui;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;

/**
 * Des:
 * Author: Bob
 * Date:20-7-28
 * UpdateRemark:
 */
public interface IPresenter extends LifecycleObserver {

//    void onAttach();
//    void onCreate();
//    void onCreateView();

    @OnLifecycleEvent(Lifecycle.Event.ON_CREATE)
    void onActivityCreated();

    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    void onStart();

    @OnLifecycleEvent(Lifecycle.Event.ON_RESUME)
    void onResume();

    @OnLifecycleEvent(Lifecycle.Event.ON_PAUSE)
    void onPause();

    @OnLifecycleEvent(Lifecycle.Event.ON_STOP)
    void onStop();

//    void onDestroyView();

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    void onDestroy();

//    void onDetach();
}
