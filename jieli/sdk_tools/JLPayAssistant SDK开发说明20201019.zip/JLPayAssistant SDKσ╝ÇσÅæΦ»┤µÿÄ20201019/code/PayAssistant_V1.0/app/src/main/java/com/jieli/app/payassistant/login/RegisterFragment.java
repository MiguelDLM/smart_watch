package com.jieli.app.payassistant.login;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;

import com.jieli.app.payassistant.R;
import com.jieli.app.payassistant.login.presenter.RegisterPresenter;
import com.jieli.app.payassistant.ui.BaseFragment;
import com.jieli.app.payassistant.util.ToastUtil;

/**
 * Des:注册账号界面
 * Author: Bob
 * Date:20-7-28
 * UpdateRemark:
 */
public class RegisterFragment extends BaseFragment implements View.OnClickListener {

    private EditText etUsername;
    private EditText etPassword;
    private EditText etPasswordAgain;
    private Button btnSubmit;
    private RegisterPresenter mPresenter;

    public static RegisterFragment newInstance() {
        return new RegisterFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (mPresenter == null) {
            mPresenter = new RegisterPresenter(this);
            getLifecycle().addObserver(mPresenter);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_register, container, false);
        etUsername = root.findViewById(R.id.register_username);
        etPassword = root.findViewById(R.id.register_enter_password);
        etPasswordAgain = root.findViewById(R.id.register_enter_password_again);
        btnSubmit = root.findViewById(R.id.register_submit_btn);
        btnSubmit.setOnClickListener(this);
        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }

    @Override
    public void onClick(View v) {
        if (v == btnSubmit) {
            String username = etUsername.getText().toString().trim();
            String password = etPassword.getText().toString().trim();
            mPresenter.submit(username, password);
        }
    }

    public void onSubmitState(boolean state) {
        if (state) {
            ToastUtil.showToastLong(getString(R.string.success));
        } else {
            ToastUtil.showToastLong(getString(R.string.failure));
        }
    }
}
