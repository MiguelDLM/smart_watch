package com.jieli.app.payassistant;

import com.jieli.app.payassistant.bluetooth.cmd.BleCmd;
import com.jieli.app.payassistant.util.Const;
import com.jieli.app.payassistant.util.StringUtil;

import org.junit.Test;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 2020/8/28 11:25 AM
 * @desc :
 */
public class BleCmdTest {

    @Test
    public void testCmdToData() {
        BleCmd bleCmd = new BleCmd()
                .type1((byte) 0x10)
                .type2((byte) 0x01)
                .value(String.format(Const.BLE_DISTRIBUTION_NETWORK_TEMPLATE, "Xiaomi_TEST", "123456789").getBytes());
        byte[] cmdData = bleCmd.toData();
        System.out.println("cmd data-->" + StringUtil.byteToHexString(cmdData));
        System.out.println("name data-->" + StringUtil.byteToHexString( "Xiaomi_TEST".getBytes()));
        System.out.println("name data-->" + StringUtil.byteToHexString( "Xiaomi_TEST".getBytes()));
        System.out.println("cmd data-->string-->" + new String(cmdData));
    }
}
