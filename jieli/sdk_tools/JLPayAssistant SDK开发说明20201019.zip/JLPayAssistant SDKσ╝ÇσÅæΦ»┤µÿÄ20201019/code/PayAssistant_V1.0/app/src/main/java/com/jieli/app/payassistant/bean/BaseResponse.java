package com.jieli.app.payassistant.bean;

import com.google.gson.annotations.SerializedName;

/**
 * Des:
 * Author: Bob
 * Date:20-7-30
 * UpdateRemark:
 */
public class BaseResponse<T> {
    @SerializedName("code")
    public int code;
    @SerializedName("data")
    public T data;
    @SerializedName("msg")
    public String msg;
}
