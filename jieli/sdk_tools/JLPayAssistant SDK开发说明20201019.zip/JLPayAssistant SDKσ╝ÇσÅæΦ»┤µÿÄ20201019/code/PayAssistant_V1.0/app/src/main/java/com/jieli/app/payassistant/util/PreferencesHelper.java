package com.jieli.app.payassistant.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import com.jieli.app.payassistant.main.MainApplication;

import java.util.Set;

/**
 * Des:
 * Author: Bob
 * Date:20-7-29
 * UpdateRemark:
 */
public final class PreferencesHelper {
	/** Shared Preferences name */
    private static String PREFERENCES_NAME = "jieli_pay_assistant";

    public void setPreferencesName(String preferencesName){
        PREFERENCES_NAME = preferencesName;
    }

    public static void putIntValue(Context context, String key, int value) {
        SharedPreferences sp = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        editor.putInt(key, value);
        editor.apply();
    }

    public static void putIntValue(String preferencesName, String key, int value) {
        SharedPreferences sp = MainApplication.getApplication().getSharedPreferences(preferencesName, Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        editor.putInt(key, value);
        editor.apply();
    }

    public static void putLongValue(Context context, String key, long value) {
        SharedPreferences sp = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        editor.putLong(key, value);
        editor.apply();
    }

    public static void putStringValue(Context context, String key, String value) {
        SharedPreferences sp = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        editor.putString(key, value);
        editor.apply();
    }

    public static void putStringValue(String preferencesName, String key, String value) {
        SharedPreferences sp = MainApplication.getApplication().getSharedPreferences(preferencesName, Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        editor.putString(key, value);
        editor.apply();
    }
    
    public static void putBooleanValue(Context context, String key, boolean value) {
        SharedPreferences sp = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        editor.putBoolean(key, value);
        editor.apply();
    }
    
    public static void putStringSetValue(Context context, String key, Set<String> value) {
        SharedPreferences sp = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        editor.putStringSet(key, value);
        editor.apply();
    }
    
    public static void remove(Context context, String key) {
        SharedPreferences sp = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        editor.remove(key);
        editor.apply();
    }

    public static void remove(String preferencesName, String key) {
        SharedPreferences sp = MainApplication.getApplication().getSharedPreferences(preferencesName, Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        editor.remove(key);
        editor.apply();
    }

    public static SharedPreferences getSharedPreferences(Context context) {
        return context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
    }

    public static SharedPreferences getSharedPreferences(String preferencesName) {
        return MainApplication.getApplication().getSharedPreferences(preferencesName, Context.MODE_PRIVATE);
    }
}
