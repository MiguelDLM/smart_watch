package com.jieli.app.payassistant.login;


import android.graphics.Paint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.jieli.app.payassistant.BuildConfig;
import com.jieli.app.payassistant.R;
import com.jieli.app.payassistant.home.HomeFragment;
import com.jieli.app.payassistant.login.presenter.LoginPresenter;
import com.jieli.app.payassistant.main.MainActivity;
import com.jieli.app.payassistant.netconfig.BleConfigFragment;
import com.jieli.app.payassistant.settings.AboutFragment;
import com.jieli.app.payassistant.ui.BaseFragment;
import com.jieli.app.payassistant.util.Const;
import com.jieli.app.payassistant.util.Jlog;
import com.jieli.app.payassistant.util.ToastUtil;

/**
 * Des:登录界面
 * Author: Bob
 * Date:20-7-28
 * UpdateRemark:
 */
public class LoginFragment extends BaseFragment {

    private EditText editUsername;
    private EditText editPassword;
    private Button btnLogin;
    private TextView btnRegister;
    private TextView tvAboutButton;

    public static LoginFragment newInstance() {
        return new LoginFragment();
    }

    private LoginPresenter mPresenter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (mPresenter == null) {
            mPresenter = new LoginPresenter(this);
            getLifecycle().addObserver(mPresenter);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_login, container, false);
        editUsername = root.findViewById(R.id.et_username);
        editPassword = root.findViewById(R.id.et_password);
        btnLogin = root.findViewById(R.id.bt_login);
        btnRegister = root.findViewById(R.id.tv_register_btn);
        tvAboutButton = root.findViewById(R.id.tv_about_btn);
        btnRegister.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
        tvAboutButton.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
        //正式版清除账号信息
        if(!BuildConfig.DEBUG){
            editPassword.setText("");
            editUsername.setText("");
        }
        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initClickListener();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    private void initClickListener() {
        btnLogin.setOnClickListener(mClickListener);
        btnRegister.setOnClickListener(mClickListener);
        tvAboutButton.setOnClickListener(mClickListener);
    }

    private View.OnClickListener mClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if (view != null) {
                switch (view.getId()) {
                    case R.id.bt_login: {
                        String username = editUsername.getText().toString().trim();
                        String password = editPassword.getText().toString().trim();
                        mPresenter.login(username, password);
                        break;
                    }
                    case R.id.tv_register_btn:
                        if (getActivity() != null) {
                            ((MainActivity)getActivity()).switchFragment(RegisterFragment.class);
                        }
                        break;
                    case R.id.tv_about_btn:
                        if (getActivity() != null) {
                            ((MainActivity)getActivity()).switchFragment(AboutFragment.class);
                        }
                        break;
                }
            }
        }
    };

    public void onLoginState(boolean login) {
        if (login) {
            Jlog.i(tag, "Login success");
            ToastUtil.showToastLong(getString(R.string.success));
            if (getActivity() != null) {
                ((MainActivity) requireActivity()).switchFragment(HomeFragment.class);
            }
        } else {
            Jlog.e(tag, "Login failed");
            ToastUtil.showToastLong(getString(R.string.failure));
        }
    }
}
