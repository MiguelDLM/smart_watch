package com.jieli.app.payassistant.netconfig.presenter;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Build;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.jieli.app.payassistant.R;
import com.jieli.app.payassistant.bean.BaseResponse;
import com.jieli.app.payassistant.bean.BondInfo;
import com.jieli.app.payassistant.bean.BtDevInfo;
import com.jieli.app.payassistant.bluetooth.cmd.BleCmd;
import com.jieli.app.payassistant.bluetooth.cmd.Command;
import com.jieli.app.payassistant.http.HttpCode;
import com.jieli.app.payassistant.http.HttpManager;
import com.jieli.app.payassistant.http.callback.IAction;
import com.jieli.app.payassistant.netconfig.BleConfigFragment;
import com.jieli.app.payassistant.ui.AbstractPresenter;
import com.jieli.app.payassistant.util.Const;
import com.jieli.app.payassistant.util.Jlog;
import com.jieli.app.payassistant.util.PreferencesHelper;
import com.jieli.app.payassistant.util.StringUtil;
import com.jieli.lib.payassistant.BluetoothClient;
import com.jieli.lib.payassistant.core.OnBluetoothListener;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 2020/9/25 8:49 AM
 * @desc :
 */
public class BleConfigPresenter extends AbstractPresenter<BleConfigFragment> {

    private static final int PERMISSION_REQUEST_CODE = 0x123;
    private static final int BLUETOOTH_REQUEST_CODE = 0x122;
    private ConfigState configState = new ConfigState();
    private String ssid;
    private String password;
    private BluetoothClient mBluetooothClient;

    public BleConfigPresenter(BleConfigFragment bleConfigFragment) {
        super(bleConfigFragment);
        mBluetooothClient = new BluetoothClient(bleConfigFragment.requireContext().getApplicationContext());
    }

    @Override
    public void onStart() {
        Jlog.i(tag, "onStart");
        mBluetooothClient.registerBluetoothListener(onBluetoothListener);
    }

    @Override
    public void onStop() {
        Jlog.i(tag, "onStop");
        mBluetooothClient.stopScanning();
        mBluetooothClient.unregisterBluetoothListener(onBluetoothListener);
    }

    //配网
    public void config(String ssid, String password) {
        if (configState.getState() != ConfigState.STATE_UNKNOWN) {
            return;
        }
        if (checkPermission()) {
            this.ssid = ssid;
            this.password = password;
            if (mBluetooothClient.getConnectedDevice() != null) {
                sendWifiInfoToDevice();
            } else {
                mBluetooothClient.startScanning();
                configState.setState(ConfigState.STATE_SCAN);
                viewContext.onProgressMsg(viewContext.getString(R.string.msg_ble_config_scaning));
            }
        }

    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean isAllGranted = true;
            for (int grant : grantResults) {
                if (grant != PackageManager.PERMISSION_GRANTED) {
                    isAllGranted = false;
                    break;
                }
            }
            if (!isAllGranted) {
                if (Build.VERSION.SDK_INT >= 23) {
                    viewContext.requestPermissions(permissions, PERMISSION_REQUEST_CODE);
                }
            } else {
                Jlog.i(tag, "All permission is granted");
                config(this.ssid, this.password);
            }
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == BLUETOOTH_REQUEST_CODE) {
            if (!BluetoothAdapter.getDefaultAdapter().isEnabled()) {
                viewContext.onFailure(viewContext.getString(R.string.bluetooth_open_tip));
            } else {
                // 继续配网
                config(this.ssid, this.password);
            }
        }
    }


    private final OnBluetoothListener onBluetoothListener = new OnBluetoothListener() {

        @Override
        public void onScanningStop() {
            super.onScanningStop();
            //结束扫描都没有发现设备则认为配对失败
            if (configState.getState() == ConfigState.STATE_SCAN) {
                configState.setState(ConfigState.STATE_UNKNOWN);
                viewContext.onFailure(viewContext.getString(R.string.msg_ble_failed_scan));
            }
        }

        @Override
        public void onFound(BluetoothDevice device) {
            //1、发现设备直接连接
            configState.setState(ConfigState.STATE_CONNECT);
            viewContext.onProgressMsg(viewContext.getString(R.string.msg_ble_config_connecting));
            mBluetooothClient.connect(device);
        }

        @Override
        public void onMtuChange(int mtu) {
            super.onMtuChange(mtu);
            //mtu请求是连接的最后一步，认为在这里就是ble环境准备成功
            sendWifiInfoToDevice();
        }

        @Override
        public void onConnectDeviceFailure(BluetoothDevice device, String msg) {
            //设备断开连接
            Jlog.i(tag, "onConnectDeviceFailure--->" + msg);
            //连接状态时需要关心设备是否异常断开
            if (configState.getState() == ConfigState.STATE_CONNECT || configState.getState() == ConfigState.STATE_DISCOVERY) {
                configState.setState(ConfigState.STATE_UNKNOWN);
                viewContext.onFailure(viewContext.getString(R.string.msg_ble_failed_connecting));
            }
        }


        @Override
        public void onReceived(byte[] data) {
            Jlog.i(tag, "recv--->data=" + StringUtil.byteToHexString(data));
            BleCmd bleCmd = BleCmd.fromData(data);
            if (bleCmd == null) {
                Jlog.e(tag, "bleCmd is null");
                return;
            }
            Jlog.i(tag, "getType==" + bleCmd.getType());
            if (bleCmd.getType() == Command.Device.NET_CONFIG) {
                //配网成功，发现设备
                handleNetConfigResponse(bleCmd);
            } else if (bleCmd.getType() == Command.Device.DISCOVERY) {
                String response = new String(bleCmd.getValue());
                TypeToken<BtDevInfo> typeToken = new TypeToken<BtDevInfo>() {
                };
                BtDevInfo btDevInfo = new Gson().fromJson(response, typeToken.getType());
                handleDiscoverySuccess(btDevInfo);
            } else {
                Jlog.w(tag, "Unknown type=" + bleCmd.getType());
            }
        }
    };

    //发送wifi信息给设备
    private void sendWifiInfoToDevice() {
        configState.setState(ConfigState.STATE_CONFIG_NET);
        viewContext.onProgressMsg(viewContext.getString(R.string.msg_ble_config_config));
        String pairStr = String.format(Const.BLE_DISTRIBUTION_NETWORK_TEMPLATE, ssid, password);
        BleCmd bleCmd = new BleCmd()
                .type(Command.App.NET_CONFIG)
                .value(pairStr.getBytes());
        mBluetooothClient.tryToSend(bleCmd.toData());
    }


    //处理设备发现成功命令
    private void handleDiscoverySuccess(BtDevInfo info) {
        configState.setState(ConfigState.STATE_BIND);
        checkBinded(info);
    }


    //查询已绑定的设备
    private void checkBinded(BtDevInfo btDevInfo) {
        viewContext.onProgressMsg(viewContext.getString(R.string.msg_ble_config_check_bind));
        String token = PreferencesHelper.getSharedPreferences(mApplication).getString(Const.SP_ACCESS_TOKEN, "");
        HttpManager.getInstance().tryToRequestBondDevice(token, new IAction<BaseResponse<BondInfo>>() {
            @Override
            public void onSuccess(BaseResponse<BondInfo> response) {
                if (response.code == HttpCode.RESPONSE_SUCCESS) {
                    Jlog.i(tag, "onBondDevice msg:" + response.data);
                    BondInfo bondInfo = response.data;
                    if (bondInfo == null) {
                        bindDevice(btDevInfo);
                    } else if (bondInfo.clientId.equals(btDevInfo.clientId) && bondInfo.username.equals(btDevInfo.username)) {
                        //用户已绑定了改设备
                        configState.setState(ConfigState.STATE_UNKNOWN);
                        viewContext.onSuccess(bondInfo.clientId);
                    } else {
                        unbindDevice(btDevInfo);
                    }

                } else {
                    Jlog.e(tag, "onBondDevice msg:" + response.msg);
                    onError(response.code, response.msg);
                }
            }

            @Override
            public void onError(int code, String message) {
                Jlog.e(tag, "queryBondDevice:code=" + code + ", onError=" + message);
                configState.setState(ConfigState.STATE_UNKNOWN);
                viewContext.onFailure(viewContext.getString(R.string.msg_ble_failed_bind));
            }
        });
    }


    //解绑设备
    private void unbindDevice(BtDevInfo btDevInfo) {
        String token = PreferencesHelper.getSharedPreferences(mApplication).getString(Const.SP_ACCESS_TOKEN, "");
        viewContext.onProgressMsg(viewContext.getString(R.string.msg_ble_config_unbind_old));
        HttpManager.getInstance().tryToUnbind(token, new IAction<BaseResponse<Boolean>>() {
            @Override
            public void onSuccess(BaseResponse<Boolean> response) {
                if (response.code == HttpCode.RESPONSE_SUCCESS) {
                    bindDevice(btDevInfo);
                } else {
                    Jlog.e(tag, "code=" + response.code + ", onError=" + response.msg);
                    onError(response.code, response.msg);
                }
            }

            @Override
            public void onError(int code, String message) {
                Jlog.e(tag, "code=" + code + ", onError=" + message);
                configState.setState(ConfigState.STATE_UNKNOWN);
                viewContext.onFailure(viewContext.getString(R.string.msg_ble_failed_bind));
            }
        });
    }

    private void bindDevice(BtDevInfo info) {
        String token = PreferencesHelper.getSharedPreferences(mApplication).getString(Const.SP_ACCESS_TOKEN, "");
        viewContext.onProgressMsg(viewContext.getString(R.string.msg_ble_config_bind));
        HttpManager.getInstance().tryToBind(token, info.clientId, info.bindToken, new IAction<BaseResponse<Object>>() {
            @Override
            public void onSuccess(BaseResponse<Object> response) {
                if (response.code == HttpCode.RESPONSE_SUCCESS) {
                    //绑定设备成功
                    configState.setState(ConfigState.STATE_UNKNOWN);
                    viewContext.onSuccess(info.clientId);
                } else {
                    Jlog.e(tag, "code=" + response.code + ", onError=" + response.msg);
                    onError(response.code, response.msg);
                }
            }

            @Override
            public void onError(int code, String message) {
                Jlog.e(tag, "code=" + code + ", onError=" + message);
                configState.setState(ConfigState.STATE_UNKNOWN);
                viewContext.onFailure(viewContext.getString(R.string.msg_ble_failed_disovery));
            }
        });
    }


    //处理配网回复命令
    private void handleNetConfigResponse(BleCmd bleCmd) {
        String resStr = new String(bleCmd.getValue());
        Jlog.i(tag, "recv distribution cmd response-->" + resStr);
        try {
            JSONObject jsonObject = new JSONObject(resStr);
            int status = jsonObject.getInt("status");
            if (status == 0) {
                configState.setState(ConfigState.STATE_DISCOVERY);
                viewContext.onProgressMsg(viewContext.getString(R.string.msg_ble_config_discovery));
                BleCmd discoveryCmd = new BleCmd()
                        .type(Command.App.DISCOVERY)
                        .value("{}".getBytes());
                mBluetooothClient.tryToSend(discoveryCmd.toData());
            } else if (status == 1) {
                Jlog.w(tag, "正在配网");
//                viewContext.onFailure(viewContext.getString(R.string.failure));
            } else if (status == 2) {
                viewContext.onFailure(viewContext.getString(R.string.failure));
            } else if (status == 3) {
                viewContext.onFailure(viewContext.getString(R.string.no_corresponding_wifi));
            } else if (status == 4) {
                viewContext.onFailure(viewContext.getString(R.string.password_incorrect));
            }
            //配网失败
            if (status > 1) {
                configState.setState(ConfigState.STATE_UNKNOWN);
                viewContext.onFailure(viewContext.getString(R.string.msg_ble_failed_config));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private boolean checkPermission() {
        // 检查是否支持BLE蓝牙
        if (!viewContext.requireActivity().getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            viewContext.onFailure(viewContext.getString(R.string.msg_ble_failed_not_support_ble));
            return false;
        }

        // 检查蓝牙开关
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        Jlog.e(tag, "isEnabled " + adapter.isEnabled());
        if (!adapter.isEnabled()) {
            viewContext.startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), BLUETOOTH_REQUEST_CODE);
            return false;
        }

        //gps开关判断
        LocationManager locManager = (LocationManager) viewContext.requireContext().getSystemService(Context.LOCATION_SERVICE);
        boolean open = locManager != null && locManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        if (!open) {
            viewContext.onFailure(viewContext.getString(R.string.open_gps_tip));
            return false;
        }
        boolean isAllGranted = true;
        if (Build.VERSION.SDK_INT >= 23) {
            String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
            for (String str : permissions) {
                Jlog.i(tag, "str=" + str);
                if (viewContext.requireActivity().checkSelfPermission(str) != PackageManager.PERMISSION_GRANTED) {
                    viewContext.requestPermissions(permissions, PERMISSION_REQUEST_CODE);
                    isAllGranted = false;
                    break;
                }
            }
        }
        return isAllGranted;
    }


    private class ConfigState {
        final static int STATE_UNKNOWN = -1;
        final static int STATE_SCAN = 0;
        final static int STATE_CONNECT = 1;
        final static int STATE_CONFIG_NET = 2;
        final static int STATE_DISCOVERY = 3;
        final static int STATE_BIND = 4;

        private int State = STATE_UNKNOWN;

        public void setState(int state) {
            State = state;
        }

        public int getState() {
            return State;
        }

        public boolean isRunning() {
            return getState() != STATE_UNKNOWN;
        }
    }

}
