package com.jieli.app.payassistant.mqtt.core;

import android.content.Context;
import android.text.TextUtils;

import com.jieli.app.payassistant.util.Jlog;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.DisconnectedBufferOptions;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.util.Arrays;

/**
 * Des:MQTT管理类
 * Author: Bob
 * Date:20-7-28
 * UpdateRemark:
 */
public class MqttManager {
    private String tag = getClass().getSimpleName();

    private static class Singleton {
        private static final MqttManager MQTT_CLIENT = new MqttManager();
    }

    private static final String MQTT_HOST = "log.jieliapp.com";
    private static final int MQTT_PORT = 1883;
    private MqttAndroidClient mqttAndroidClient;
    private MqttConnectOptions mqttConnectOptions = null;
    private OnMqttListener onMqttListener;

    public static MqttManager getInstance() {
        return Singleton.MQTT_CLIENT;
    }

    public void create(Context context, String clientId, String username, String password) {
        String protocol = "tcp://";
        String serverUri = protocol + MQTT_HOST + ":" + MQTT_PORT;

        Jlog.i(tag, "createMqtt: server=" + serverUri + ", clientID=" + clientId);
        mqttAndroidClient = new MqttAndroidClient(context.getApplicationContext(), serverUri, clientId);
        mqttAndroidClient.setCallback(mqttCallbackExtended);

        mqttConnectOptions = new MqttConnectOptions();
        mqttConnectOptions.setUserName(username);
        mqttConnectOptions.setPassword(password.toCharArray());
        mqttConnectOptions.setConnectionTimeout(10);//设置超时时间，单位：秒
        mqttConnectOptions.setKeepAliveInterval(5);//设置心跳包发送间隔，单位：秒
        mqttConnectOptions.setAutomaticReconnect(true);
        mqttConnectOptions.setCleanSession(true);//设置是否清除缓存

        doConnection();
    }

    private final IMqttActionListener mqttActionListener = new IMqttActionListener() {
        @Override
        public void onSuccess(IMqttToken iMqttToken) {
            Jlog.i(tag, "connect onSuccess");
            DisconnectedBufferOptions disconnectedBufferOptions = new DisconnectedBufferOptions();
            disconnectedBufferOptions.setBufferEnabled(true);
            disconnectedBufferOptions.setBufferSize(100);
            disconnectedBufferOptions.setPersistBuffer(false);
            disconnectedBufferOptions.setDeleteOldestMessages(false);
            mqttAndroidClient.setBufferOpts(disconnectedBufferOptions);
        }

        @Override
        public void onFailure(IMqttToken iMqttToken, Throwable throwable) {
            Jlog.e(tag, "connect onFailure");
        }
    };

    private final MqttCallbackExtended mqttCallbackExtended = new MqttCallbackExtended() {
        @Override
        public void connectComplete(boolean reconnect, String serverURI) {
            Jlog.i(tag, "connectComplete: " + reconnect);
            if (onMqttListener != null) {
                onMqttListener.onConnected();
            }
            if (reconnect) {
                Jlog.i(tag, "Reconnected to : " + serverURI);
                // Because Clean Session is true, we need to re-subscribe
                if (onMqttListener != null) onMqttListener.onReconnected();
            } else {
                Jlog.i(tag, "Connected to: " + serverURI);
            }
        }

        @Override
        public void connectionLost(Throwable cause) {
            Jlog.w(tag, "The Connection was lost.");
            doConnection();
        }

        @Override
        public void messageArrived(String topic, MqttMessage message) {
            Jlog.i(tag, "messageArrived: topic=" + topic + ", payload=" + new String(message.getPayload()));
            if (onMqttListener != null) onMqttListener.onReceived(topic, message);
        }

        @Override
        public void deliveryComplete(IMqttDeliveryToken token) {
            if (onMqttListener != null) onMqttListener.onSent();
            try {
                Jlog.i(tag, "deliveryComplete: " + token.getMessage().toString());
            } catch (MqttException e) {
                e.printStackTrace();
            }
        }
    };

    /**
     * 连接MQTT服务器
     */
    private void doConnection() {
        if (!mqttAndroidClient.isConnected()) {
            try {
                mqttAndroidClient.connect(mqttConnectOptions, null, mqttActionListener);
            } catch (MqttException e) {
                e.printStackTrace();
            }
        } else {
            Jlog.w(tag, "Has connected");
        }
    }

    public void close() {
        if (mqttAndroidClient != null) {
            try {
                mqttAndroidClient.disconnect();
            } catch (MqttException e) {
                e.printStackTrace();
            }
            mqttAndroidClient.close();
            mqttAndroidClient.unregisterResources();
        }
    }

    public boolean isConnected() {
        return mqttAndroidClient != null && mqttAndroidClient.isConnected();
    }

    public void subscribe(String[] topic) {
        if (mqttAndroidClient == null) {
            Jlog.e(tag, "MQTT client has not created yet!");
            return;
        }
        int[] qos = new int[topic.length];
        Arrays.fill(qos, 2);
        try {
            mqttAndroidClient.subscribe(topic, qos, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken iMqttToken) {
                    Jlog.i(tag, "Subscribed!! " + iMqttToken.getTopics()[0]);
                }

                @Override
                public void onFailure(IMqttToken iMqttToken, Throwable throwable) {
                    Jlog.e(tag, "Failed to subscribe:" + iMqttToken.getTopics()[0]);
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void subscribe(String topic) {
        Jlog.i(tag, "subscribe: topic=" + topic);
        if (mqttAndroidClient == null) {
            Jlog.e(tag, "MQTT client has not created yet!");
            return;
        }
        try {
            mqttAndroidClient.subscribe(topic, 2, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken iMqttToken) {
                    Jlog.i(tag, "Subscribed!! " + iMqttToken.getTopics()[0]);
                }

                @Override
                public void onFailure(IMqttToken iMqttToken, Throwable throwable) {
                    Jlog.e(tag, "Failed to subscribe:" + iMqttToken.getTopics()[0]);
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publish(String topic, String publishMessage) {
        Jlog.i(tag, "publish: topic=" + topic + ", publish msg=" + publishMessage);
        if (mqttAndroidClient == null) {
            Jlog.e(tag, "MQTT client has not created yet!");
            return;
        }
        try {
            MqttMessage message = new MqttMessage();
            message.setQos(2);
            if (!TextUtils.isEmpty(publishMessage)) {
                message.setPayload(publishMessage.getBytes());
            }
            mqttAndroidClient.publish(topic, message, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken iMqttToken) {
                    Jlog.w(tag, "Message Published");
                }

                @Override
                public void onFailure(IMqttToken iMqttToken, Throwable throwable) {
                    Jlog.e(tag, "Published failed");
                }
            });

            if (!mqttAndroidClient.isConnected()) {
                Jlog.w(tag, mqttAndroidClient.getBufferedMessageCount() + " messages still in buffer.");
            }
        } catch (MqttException e) {
            Jlog.e(tag, "Error Publishing: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void setOnMqttListener(OnMqttListener listener) {
        onMqttListener = listener;
    }

    public interface OnMqttListener {
        void onConnected();
        void onReconnected();
        void onReceived(String topic, MqttMessage message);
        void onSent();
    }
}
