package com.jieli.app.payassistant.util;

import android.os.Handler;
import android.os.Looper;

public final class HandlerUtil {
    private static Handler mHandler;

    public static void post(Runnable runnable) {
        postDelayed(runnable, 0);
    }

    public static void postDelayed(Runnable runnable, long delayInMillis) {
        if (mHandler == null) {
            mHandler = new Handler(Looper.getMainLooper());
        }
        mHandler.postDelayed(runnable, delayInMillis);
    }
}
