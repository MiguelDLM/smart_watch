package com.jieli.app.payassistant.util;

import com.jieli.app.payassistant.main.MainApplication;

/**
 * Des:
 * Author: Bob
 * Date:20-7-15
 * UpdateRemark:
 */
public final class Actions {
    private static final String ACTION_PREFIX = MainApplication.getApplication().getPackageName() + "_";
    public static final String ACTION_APP_NOTIFICATION = ACTION_PREFIX + "app_notification";
    public static final String ACTION_NOTIFICATION_SERVICE_CONNECTED = ACTION_PREFIX + "notification_service_connected";
    public static final String KEY_NOTIFICATION_TITLE = "notification_title";
    public static final String KEY_NOTIFICATION_CONTENT = "notification_content";
    public static final String KEY_NOTIFICATION_MONEY = "notification_money";
    public static final String KEY_NOTIFICATION_APP = "notification_app";

    public static final String ACTION_MQTT_RECONNECTED = ACTION_PREFIX + "mqtt_reconnected";
}
