package com.jieli.app.payassistant.bean;

import com.google.gson.annotations.SerializedName;

import java.util.Objects;

/**
 * Des:
 * Author: Bob
 * Date:20-9-17
 * UpdateRemark:
 */
public class BondInfo {
    @SerializedName("clientid")
    public String clientId;
    @SerializedName("type")
    public String type;
    @SerializedName("username")
    public String username;

    @Override
    public String toString() {
        return "BondInfo{" +
                "clientId='" + clientId + '\'' +
                ", type='" + type + '\'' +
                ", username='" + username + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BondInfo bondInfo = (BondInfo) o;
        return clientId.equals(bondInfo.clientId) &&
                username.equals(bondInfo.username);
    }

    @Override
    public int hashCode() {
        return Objects.hash(clientId, username);
    }
}
