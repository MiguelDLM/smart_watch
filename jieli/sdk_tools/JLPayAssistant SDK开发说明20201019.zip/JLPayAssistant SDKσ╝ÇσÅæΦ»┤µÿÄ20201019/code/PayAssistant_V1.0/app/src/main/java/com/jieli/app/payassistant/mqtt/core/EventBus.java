package com.jieli.app.payassistant.mqtt.core;

import com.jieli.app.payassistant.bean.TopicInfo;

import java.util.HashSet;

/**
 * Des:命令分发总线类
 * Author: Bob
 * Date:20-3-23
 * UpdateRemark:
 */
public final class EventBus implements IObservable<TopicInfo> {
    private final HashSet<IObserver<TopicInfo>> mObservers = new HashSet<>();

    private static class Singleton {
        private final static EventBus sInstance = new EventBus();
    }

    public static EventBus getInstance() {
        return Singleton.sInstance;
    }

    @Override
    public void register(IObserver<TopicInfo> observer) {
        synchronized (mObservers) {
            mObservers.add(observer);
        }
    }

    @Override
    public void unregister(IObserver<TopicInfo> observer) {
        synchronized (mObservers) {
            mObservers.remove(observer);
        }
    }

    @Override
    public void unregisterAll() {
        synchronized (mObservers) {
            mObservers.clear();
        }
    }

    @Override
    public void notify(TopicInfo cmdInfo) {
        synchronized (mObservers) {
            for (IObserver<TopicInfo> o : mObservers) {
                o.onCommand(cmdInfo);
            }
        }
    }
}
