package com.jieli.app.payassistant.main.presenter;

import com.jieli.app.payassistant.main.MainActivity;
import com.jieli.app.payassistant.ui.AbstractPresenter;
import com.jieli.app.payassistant.util.CommonUtil;

/**
 * Des:
 * Author: Bob
 * Date:20-9-16
 * UpdateRemark:
 */
public class MainPresenter  extends AbstractPresenter<MainActivity> {
    public MainPresenter(MainActivity mainActivity) {
        super(mainActivity);
    }

    @Override
    public void onActivityCreated() {
        viewContext.startWorking();
    }

    public boolean enableNotification() {
        return CommonUtil.isNotificationEnabled(viewContext);
    }
}
