package com.jieli.app.payassistant.http;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * Des:
 * Author: Bob
 * Date:20-7-29
 * UpdateRemark:
 */
public interface IHttpApi {

    /**
     * 用户注册
     * @param username 随机生成唯一码：android获取 IMEI号（DeviceId）、IMSI号、ANDROID_ID、序列号（SerialNumber）
     * @param password 密码
     * @param type user 表示用户手机移动端
     * @return strings
     */
    @POST("/payassistant/v1/auth/register")
    Call<String> register(@Query("username")String username, @Query("password")String password, @Query("type")String type);

    /**
     * 用户登录
     * @param username 帐号
     * @param password 密码
     * @param type user表示手机端登录 device表示设备登录
     * @return
     */
    @POST("/payassistant/v1/auth/login")
    Call<String> login(@Query("username")String username, @Query("password")String password, @Query("type")String type);

    /**
     * 设备发现
     * @param jwtToken
     * @return strings
     */
    @GET("/payassistant/v1/user/device/discovery")
    Call<String> discovery(@Header("jwt-token")String jwtToken);

    /**
     * 绑定设备
     * @param jwtToken
     * @param clientId
     * @param bindToken
     * @return strings
     */
    @POST("/payassistant/v1/user/device/bind")
    Call<String> bind(@Header("jwt-token")String jwtToken, @Query("clientid")String clientId, @Query("bindToken")String bindToken);

    /**
     * 解绑设备
     * @param jwtToken
     * @return strings
     */
    @POST("/payassistant/v1/user/device/unbind")
    Call<String> unbind(@Header("jwt-token")String jwtToken);

    /**
     * 获取当前绑定设备
     * @param jwtToken
     * @return strings
     */
    @GET("/payassistant/v1/user/device/one")
    Call<String> getBoundDevice(@Header("jwt-token")String jwtToken);

    /**
     * 获取实际IP地址
     * @param jwtToken
     * @return strings
     */
    @GET("/payassistant/v1/user/device/myip")
    Call<String> getAddress(@Header("jwt-token")String jwtToken);

    /**
     * Token检查
     * @param token
     * @return strings
     */
    @GET("/payassistant/v1/auth/check")
    Call<String> checkToken( @Query("token")String token);

    /**
     * Token刷新
     * @param token
     * @return strings
     */
    @GET("/payassistant/v1/auth/refresh")
    Call<String> refreshToken(@Query("token")String token);

    /**
     * 查询用户信息
     * @param token
     * @return strings
     */
    @GET("/payassistant/v1/auth/info")
    Call<String> queryUserInfo(@Query("token")String token);
}
