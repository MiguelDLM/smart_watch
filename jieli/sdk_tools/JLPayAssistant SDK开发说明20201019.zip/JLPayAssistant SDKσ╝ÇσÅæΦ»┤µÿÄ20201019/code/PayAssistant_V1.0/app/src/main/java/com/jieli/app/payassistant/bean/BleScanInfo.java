package com.jieli.app.payassistant.bean;

import android.bluetooth.BluetoothDevice;

import java.util.Objects;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 2020/8/31 10:01 AM
 * @desc :
 */
public class BleScanInfo {
    private BluetoothDevice bluetoothDevice;
    private boolean connected;

    public BleScanInfo(BluetoothDevice bluetoothDevice, boolean connected) {
        this.bluetoothDevice = bluetoothDevice;
        this.connected = connected;
    }

    public BleScanInfo() {
    }

    public BluetoothDevice getBluetoothDevice() {
        return bluetoothDevice;
    }

    public void setBluetoothDevice(BluetoothDevice bluetoothDevice) {
        this.bluetoothDevice = bluetoothDevice;
    }

    public boolean isConnected() {
        return connected;
    }

    public void setConnected(boolean connected) {
        this.connected = connected;
    }

    @Override
    public int hashCode() {
        return Objects.hash(bluetoothDevice);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        final BleScanInfo other = (BleScanInfo) obj;
        return Objects.equals(this.bluetoothDevice, other.bluetoothDevice);
    }
}
