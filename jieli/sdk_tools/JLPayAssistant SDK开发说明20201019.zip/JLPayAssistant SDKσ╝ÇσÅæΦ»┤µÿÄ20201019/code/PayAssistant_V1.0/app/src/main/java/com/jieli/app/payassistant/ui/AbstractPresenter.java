package com.jieli.app.payassistant.ui;

import com.jieli.app.payassistant.main.MainApplication;

/**
 * Des:
 * Author: Bob
 * Date:20-7-28
 * UpdateRemark:
 */
public abstract class AbstractPresenter<T> implements IPresenter {
    protected String tag = getClass().getSimpleName();
    protected T viewContext;
    protected MainApplication mApplication;

    public AbstractPresenter(T t) {
        viewContext = t;
        mApplication = MainApplication.getApplication();
    }

    @Override
    public void onActivityCreated() {

    }

    @Override
    public void onStart() {

    }

    @Override
    public void onResume() {

    }

    @Override
    public void onPause() {

    }

    @Override
    public void onStop() {

    }

    @Override
    public void onDestroy() {

    }
}
