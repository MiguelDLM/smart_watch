package com.jieli.app.payassistant.http.callback;

/**
 * Des:
 * Author: Bob
 * Date:20-7-29
 * UpdateRemark:
 */
public interface IAction<T> {
    void onSuccess(T response);

    void onError(int code, String message);
}
