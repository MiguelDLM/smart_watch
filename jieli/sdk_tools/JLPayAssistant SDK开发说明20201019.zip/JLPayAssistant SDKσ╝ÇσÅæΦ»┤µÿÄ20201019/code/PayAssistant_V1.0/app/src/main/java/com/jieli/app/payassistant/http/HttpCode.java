package com.jieli.app.payassistant.http;

/**
 * Des:
 * Author: Bob
 * Date:20-7-29
 * UpdateRemark:
 */
public final class HttpCode {
    public static final int RESPONSE_SUCCESS = 0;
    public static final int RESPONSE_FAILURE = -1;

    public static final int SUCCESS_HTTP_RESPONSE = 0;
    public static final int SUCCESS_HTTP_RESPONSE_OK = 200;

    public static final int ERROR_CLIENT_INIT = 1000; //客户端初始化失败
    public static final int ERROR_PARAMS = 1001; //参数错误
    public static final int ERROR_NETWORK_EXCEPTION = 1002; //网络异常
    public static final int ERROR_NETWORK_RESPONSE = 1003; //网络回复异常
    public static final int ERROR_SERVER_RESPONSE = 1004; //服务器回复异常
    public static final int ERROR_RESPONSE_DATA = 1005; //数据异常
}
