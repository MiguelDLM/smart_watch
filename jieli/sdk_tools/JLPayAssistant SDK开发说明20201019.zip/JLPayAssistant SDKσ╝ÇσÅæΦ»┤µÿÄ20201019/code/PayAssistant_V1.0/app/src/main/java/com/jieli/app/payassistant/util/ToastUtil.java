package com.jieli.app.payassistant.util;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;
import android.widget.Toast;

import java.lang.ref.WeakReference;

/**
 * Des:
 * Author: Bob
 * Date:20-7-30
 * UpdateRemark:
 */
public final class ToastUtil {
    private static String tag = ToastUtil.class.getSimpleName();

    // 弱引用Context。
    private static WeakReference<Context> contextWeakReference;

    /**
     * 初始化Toast管理器。
     *
     * @param context 系统的Context。
     */
    public static void init(Context context) {
        if(context == null) return;
        ToastUtil.contextWeakReference = new WeakReference<>(context.getApplicationContext());
    }

    /**
     * 显示内容。
     *
     * @param msg      内容
     * @param duration 显示间隔
     */
    @SuppressLint("ShowToast")
    private static void showToast(String msg, int duration) {
        if (contextWeakReference == null) {
            throw new RuntimeException("Have not init toast utils");
        }
        if (contextWeakReference.get() == null) {
            Jlog.e(tag, "contextWeakReference.get is null ");
            return;
        }
        if (!TextUtils.isEmpty(msg) && duration >= 0) {
            Toast toast = Toast.makeText(contextWeakReference.get(), msg, duration);
            toast.setText(msg);
            toast.setDuration(duration);
            toast.show();
        } else {
            Jlog.e(tag, "Error: msg=" + msg +", duration=" + duration);
        }
    }

    public static void showToastShort(String info) {
        showToast(info, Toast.LENGTH_SHORT);
    }

    public static void showToastLong(String msg) {
        showToast(msg, Toast.LENGTH_LONG);
    }
}
