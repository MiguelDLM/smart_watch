package com.jieli.app.payassistant.bluetooth.cmd;

/**
 * Des:
 * Author: Bob
 * Date:20-9-10
 * UpdateRemark:
 */
public final class Command {
    public final static class App {
        /**
         * 用户端发往设备端，设置当前用户端已知wifi名称及密码
         */
        public static final short NET_CONFIG = 0X1001;

        /**
         * 用户端发往设备端，请求设备端发送设备信息
         */
        public static final short DISCOVERY = 0X1003;
    }

    /**
     * 设备回复/响应
     */
    public final static class Device {
        /**
         * 设备端发往用户端，应答配网状态
         * 状态0表示配网成功，非0表示配网失败
         * 0 -- 配网成功
         * 1 -- 正在配网
         * 2 -- 配网失败
         * 3 -- 未找到相应wifi
         * 4 -- 密码错误
         */
        public static final short NET_CONFIG = 0X1002;

        /**
         * 设备端发往用户端，应答发送设备信息给用户端，用户端使用设备信息进行绑定操作、设备交互
         */
        public static final short DISCOVERY = 0X1004;
    }
}
